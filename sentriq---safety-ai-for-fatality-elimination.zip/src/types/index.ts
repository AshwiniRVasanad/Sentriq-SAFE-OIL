export type ReportType = 'Unsafe Act' | 'Unsafe Condition' | 'Near Miss' | 'Incident';
export type ReporterType =
  | 'Frontline Worker'
  | 'Roustabout'
  | 'Driller'
  | 'HSE Officer'
  | 'Toolpusher'
  | 'Subcontractor'
  | 'Maintenance Tech';

export type RiskLevel = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type SIFPotential = 'YES' | 'NO' | 'POTENTIAL';

export type IOGPRule =
  | 'Energy Isolation'
  | 'Bypassing Safety Controls'
  | 'Confined Space'
  | 'Driving'
  | 'Hot Work'
  | 'Line of Fire'
  | 'Safe Mechanical Lifting'
  | 'Work Authorization'
  | 'Working at Height';

export interface HighlightedPhrase {
  text: string;
  category: 'critical' | 'risk' | 'context';
  reason: string;
}

export interface Explainability {
  highlightedPhrases: HighlightedPhrase[];
  triggers: string[];
  reasoning: string;
  method: string;
}

export interface FailedBarriers {
  hardware: string[];
  procedural: string[];
  human: string[];
}

export interface BowtieBarrier {
  name: string;
  status: 'effective' | 'degraded' | 'failed';
  type: 'hardware' | 'procedural' | 'human';
}

export interface BowtieAnalysis {
  threats: string[];
  preventiveBarriers: BowtieBarrier[];
  topEvent: string;
  mitigatingBarriers: BowtieBarrier[];
  potentialConsequences: string[];
  whatCouldHappen: string;
  howToBreakTheChain: string[];
}

export interface LanguageCardContent {
  title: string;
  hazard: string;
  whatHappened: string;
  whatCouldHappen: string;
  checks: string[];
}

export interface WorkerCard {
  title: string;
  hazard: string;
  risk: string;
  iogpRule: string;
  whatHappened: string;
  whatCouldHappen: string;
  mandatoryChecks: string[];
  languageTranslations: {
    en: LanguageCardContent;
    hi: LanguageCardContent;
    as: LanguageCardContent;
  };
}

export interface FleetOperation {
  site: string;
  rigId: string;
  activity: string;
  equipment: string;
  similarityScore: number;
  status: 'Active' | 'Standby' | 'Tripping' | 'Workover';
  riskScore: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  lastReportDate: string;
  precursorMatch: string;
}

export interface CAPARecord {
  id: string;
  reportId: string;
  title: string;
  correctiveAction: string;
  preventiveAction: string;
  responsibleRole: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  targetDate: string;
  verificationMethod: string;
  status: 'Draft' | 'Approved' | 'In Progress' | 'Verified';
  aiGenerated: boolean;
  createdAt: string;
}

export interface SafetyReport {
  report_id: string;
  timestamp: string;
  site: string;
  rig_id: string;
  location: string;
  activity: string;
  report_type: ReportType;
  reporter_type: ReporterType;
  raw_text: string;
  sif_potential: SIFPotential;
  risk_level: RiskLevel;
  sif_confidence: number;
  confidence_label: string;
  iogp_primary: string;
  iogp_secondary?: string;
  energy_source: string;
  equipment: string;
  failed_barriers: FailedBarriers;
  potential_consequence: string;
  explainability: Explainability;
  bowtie: BowtieAnalysis;
  worker_card: WorkerCard;
  status: 'FLAGGED' | 'UNDER_REVIEW' | 'VERIFIED' | 'RESOLVED';
  human_verification_status: 'Awaiting authorized HSE verification' | 'Approved' | 'Declined';
}

export interface DashboardSummary {
  totalReports: number;
  sifPotentialCount: number;
  highRiskCount: number;
  criticalBarriersCount: number;
  iogpRulesTriggeredCount: number;
  activeFleetAlertsCount: number;
  aiWeeklyInsights: {
    title: string;
    patterns: string[];
    recommendation: string;
  };
  sifTrend: Array<{ date: string; sifCount: number; nonSifCount: number }>;
  rigDistribution: Array<{ rig: string; site: string; count: number; sifRatio: number }>;
  iogpDistribution: Array<{ rule: string; count: number; percentage: number }>;
  barrierDistribution: Array<{ barrierType: string; count: number }>;
  hazardDistribution: Array<{ category: string; count: number }>;
  recentCriticalReports: SafetyReport[];
}
