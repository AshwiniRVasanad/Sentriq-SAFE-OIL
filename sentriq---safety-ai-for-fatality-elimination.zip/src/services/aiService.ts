import { GoogleGenAI, Type } from '@google/genai';
import {
  SafetyReport,
  BowtieAnalysis,
  WorkerCard,
  CAPARecord,
  Explainability,
  FailedBarriers,
  IOGPRule,
  RiskLevel,
  SIFPotential,
  FleetOperation,
} from '../types';
import { reportsRepo } from '../data/reportsRepository';

const apiKey = process.env.GEMINI_API_KEY || '';
const hasGemini = Boolean(apiKey && apiKey.length > 5 && apiKey !== 'MY_GEMINI_API_KEY');

let ai: GoogleGenAI | null = null;
if (hasGemini) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function isGeminiConnected(): boolean {
  return hasGemini && ai !== null;
}

export async function normalizeVoiceInput(transcript: string, language: 'en' | 'hi' | 'as'): Promise<{
  original: string;
  normalized: string;
  language: string;
  suggestedActivity: string;
  suggestedLocation: string;
}> {
  const lower = transcript.toLowerCase();

  // If Gemini is available, normalize via LLM
  if (isGeminiConnected() && ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are an HSE Safety Intelligence AI for Oil & Gas operations. Translate and normalize this frontline oilfield worker voice report into a professional structured safety observation text.
Input speech: "${transcript}" (language: ${language})
Output JSON with:
- normalized: string (in professional English HSE report terminology)
- suggestedActivity: string
- suggestedLocation: string`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              normalized: { type: Type.STRING },
              suggestedActivity: { type: Type.STRING },
              suggestedLocation: { type: Type.STRING },
            },
            required: ['normalized', 'suggestedActivity', 'suggestedLocation'],
          },
        },
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        return {
          original: transcript,
          normalized: parsed.normalized,
          language,
          suggestedActivity: parsed.suggestedActivity || 'Drilling / Well Operations',
          suggestedLocation: parsed.suggestedLocation || 'Rig Wellhead / Drill Floor',
        };
      }
    } catch {
      // fallback to rule-based below
    }
  }

  // High-fidelity rule-based normalization for demo
  if (lower.includes('bop') || lower.includes('leak') || lower.includes('rokna')) {
    return {
      original: transcript,
      normalized:
        'Active hydraulic fluid / hydrocarbon seepage observed on BOP line fitting during well operations; immediate work suspension recommended pending pressure verification.',
      language: language === 'hi' ? 'Hindi (Transcribed)' : language === 'as' ? 'Assamese (Transcribed)' : 'English',
      suggestedActivity: 'Well Control / BOP Maintenance',
      suggestedLocation: 'Substructure Wellhead Cellar',
    };
  }

  if (lower.includes('harness') || lower.includes('gir') || lower.includes('height') || lower.includes('belt')) {
    return {
      original: transcript,
      normalized:
        'Personnel observed operating on elevated platform at derrick level without 100% tie-off harness connection during adverse wind conditions.',
      language,
      suggestedActivity: 'Working at Height / Tripping',
      suggestedLocation: 'Derrick Monkey Board',
    };
  }

  if (lower.includes('gas') || lower.includes('detector') || lower.includes('smell') || lower.includes('gandh')) {
    return {
      original: transcript,
      normalized:
        'Hydrocarbon gas odor reported in process area; stationary gas detector alarm unconfirmed or sensor calibration suspect in Zone 3.',
      language,
      suggestedActivity: 'Process Monitoring / Hot Work',
      suggestedLocation: 'Zone 3 Manifold Skid',
    };
  }

  return {
    original: transcript,
    normalized: `Field worker voice report: "${transcript}". Operational hazard logged for HSE verification.`,
    language,
    suggestedActivity: 'General Rig Maintenance',
    suggestedLocation: 'Rig Active Area',
  };
}

export async function explainReport(text: string): Promise<Explainability> {
  const lower = text.toLowerCase();
  const highlightedPhrases: Explainability['highlightedPhrases'] = [];
  const triggers: string[] = [];

  // Critical phrases detection
  const criticalTerms = [
    { term: 'gas detector was offline', reason: 'Hardware safety barrier bypass' },
    { term: 'gas detector offline', reason: 'Loss of flammable gas surveillance' },
    { term: 'before loto verification', reason: 'Direct failure of zero-energy isolation' },
    { term: 'without loto', reason: 'Energy isolation procedure bypassed' },
    { term: 'unhooking safety harness', reason: 'Primary fall arrest barrier removed at height' },
    { term: 'without harness', reason: 'Unprotected exposure to gravitational fall' },
    { term: 'missing safety whip-checks', reason: 'Absence of secondary catastrophic restraint' },
    { term: 'without breathing apparatus', reason: 'IDLH toxic respiratory barrier absent' },
    { term: 'h2s sensor alarm', reason: 'Fatal atmospheric gas threshold exceeded' },
    { term: 'without proving de-energization', reason: 'Live electrical conductor hazard' },
    { term: 'smoking a cigarette', reason: 'Naked ignition flame inside hazardous vapor envelope' },
    { term: 'without electrical bonding', reason: 'Electrostatic spark hazard in bulk fuel decanting' },
    { term: 'alarm was muted with tape', reason: 'Deliberate defeat of well kick safety system' },
    { term: 'stood directly under the suspended load', reason: 'Direct line-of-fire crush exposure' },
    { term: 'work continued', reason: 'Breakdown of Stop-Work Authority (SWA)' },
  ];

  criticalTerms.forEach(({ term, reason }) => {
    if (lower.includes(term)) {
      highlightedPhrases.push({
        text: term,
        category: 'critical',
        reason,
      });
      triggers.push(`${term.toUpperCase()} (${reason})`);
    }
  });

  // Risk terms
  const riskTerms = [
    { term: 'hot work', reason: 'Open thermal ignition energy source in classified zone' },
    { term: 'high-pressure', reason: 'Stored hydraulic or pneumatic line pressure' },
    { term: '4200 psi', reason: 'Extreme energy storage in fluid system' },
    { term: '5000 psi', reason: 'High-pressure well control circuit' },
    { term: '33kv', reason: 'High-voltage flashover potential' },
    { term: '90 ft', reason: 'High fall elevation severity zone' },
    { term: 'mud pump', reason: 'Dynamic oscillating high pressure iron' },
    { term: 'bop', reason: 'Critical well control primary barrier' },
    { term: 'confined space', reason: 'Atmospheric entrapment & asphyxiation risk' },
  ];

  riskTerms.forEach(({ term, reason }) => {
    if (lower.includes(term) && !highlightedPhrases.some((h) => h.text.toLowerCase() === term)) {
      highlightedPhrases.push({
        text: term,
        category: 'risk',
        reason,
      });
    }
  });

  // Context terms
  const contextTerms = [
    { term: 'zone 3', reason: 'Classified hazardous operational area' },
    { term: 'cellar', reason: 'Low-lying vapor accumulation envelope' },
    { term: 'monkey board', reason: 'Derrick elevated work area' },
    { term: 'drill floor', reason: 'Heavy rotating and hoisting activity zone' },
    { term: 'catwalk', reason: 'Tubular transfer drop hazard pathway' },
  ];

  contextTerms.forEach(({ term, reason }) => {
    if (lower.includes(term) && !highlightedPhrases.some((h) => h.text.toLowerCase() === term)) {
      highlightedPhrases.push({
        text: term,
        category: 'context',
        reason,
      });
    }
  });

  if (triggers.length === 0) {
    triggers.push('Hazardous Oil & Gas operational condition identified by NLP keyword heuristics.');
  }

  return {
    method: 'SHAP-style Feature Attribution - DEMO',
    triggers,
    reasoning:
      'Multi-token attention alignment flagged concurrent failure of protective barrier controls alongside presence of stored mechanical, thermal, or chemical energy.',
    highlightedPhrases,
  };
}

export function generateRuleBasedBowtie(
  reportText: string,
  iogpRule: string,
  energySource: string
): BowtieAnalysis {
  const lower = reportText.toLowerCase();

  if (iogpRule === 'Energy Isolation' || lower.includes('loto') || lower.includes('gas detector')) {
    return {
      threats: [
        'Accumulation of fugitive hydrocarbon vapors near hot work zone',
        'Residual pressurized oil/gas trapped behind unverified valve',
        'Defective isolation valve passing pressurized condensate',
      ],
      preventiveBarriers: [
        { name: 'Positive Mechanical Isolation (LOTO Spades/Blinds)', status: 'failed', type: 'procedural' },
        { name: 'Cold-Line De-pressurization & Bleed Verification', status: 'failed', type: 'hardware' },
        { name: 'Hot Work Permit Joint Inspection Walkdown', status: 'degraded', type: 'human' },
      ],
      topEvent: 'Loss of Containment & Uncontrolled Ignition in Hazardous Zone',
      mitigatingBarriers: [
        { name: 'Fixed & Portable Gas Detection Array (Zone 3 LEL)', status: 'failed', type: 'hardware' },
        { name: 'Fire Watch with 50kg Dry Chemical Extinguisher', status: 'degraded', type: 'human' },
        { name: 'Emergency Shutdown (ESD-1) Automatic Isolation', status: 'effective', type: 'hardware' },
      ],
      potentialConsequences: [
        'Flash fire and hydrocarbon vapor cloud explosion (VCE)',
        'Multiple personnel fatalities within 25-meter radius',
        'Structural rig damage and prolonged asset shutdown',
      ],
      whatCouldHappen:
        'IF hot work sparks ignite residual gas while LOTO is unverified AND the gas detector remains offline, THEN an immediate explosion will occur without prior audible alarm, resulting in fatal burns and structural collapse.',
      howToBreakTheChain: [
        'IMMEDIATELY exercise Stop-Work Authority (SWA) and suspend hot work.',
        'Physically verify zero energy via double-block-and-bleed gauge checks.',
        'Restore or calibrate Zone 3 gas detector; provide continuous calibrated 4-gas clip monitors.',
        'Re-issue PTW (Permit to Work) with joint Toolpusher and HSE signature verification.',
      ],
    };
  }

  if (iogpRule === 'Working at Height' || lower.includes('height') || lower.includes('harness')) {
    return {
      threats: [
        'Slip or trip on greasy or wet elevated grating',
        'Sudden wind gust destabilizing worker on elevated mast or monkey board',
      ],
      preventiveBarriers: [
        { name: 'Rigid Perimeter Handrails & Toe-boards', status: 'degraded', type: 'hardware' },
        { name: '100% Dual-Lanyard Tie-Off Anchor System', status: 'failed', type: 'procedural' },
      ],
      topEvent: 'Unprotected Fall from Elevation (> 1.8 meters)',
      mitigatingBarriers: [
        { name: 'Self-Retracting Inertia Lifeline (SRL) Fall Arrester', status: 'failed', type: 'hardware' },
        { name: 'Rig Floor Secondary Safety Catch Netting', status: 'effective', type: 'hardware' },
      ],
      potentialConsequences: [
        'Fatal blunt impact trauma onto steel drill floor or rotary table',
        'Severe spinal severance and internal hemorrhage',
      ],
      whatCouldHappen:
        'IF a worker slips while lanyards are unhooked at elevation, THEN gravity will cause an unrestricted fall to the floor below with 100% fatal impact force.',
      howToBreakTheChain: [
        'Maintain 100% tie-off using twin lanyards; never unhook both clips simultaneously.',
        'Cease elevated monkey board operations when wind speeds exceed 25 knots or during thunderstorms.',
        'Daily pre-climb inspection of harnesses and self-retracting lifelines.',
      ],
    };
  }

  // Default Bowtie model
  return {
    threats: [
      `Uncontrolled release of ${energySource || 'stored energy'}`,
      'Human error during maintenance or high-risk operational task',
    ],
    preventiveBarriers: [
      { name: 'Permit to Work (PTW) Task Risk Assessment', status: 'degraded', type: 'procedural' },
      { name: 'Engineered Safety Interlocks & Guards', status: 'failed', type: 'hardware' },
    ],
    topEvent: 'Breach of Primary Asset Barrier / Hazardous Exposure Event',
    mitigatingBarriers: [
      { name: 'Personal Protective Equipment (PPE) Matrix', status: 'effective', type: 'hardware' },
      { name: 'Emergency Stop & Site Evacuation Protocol', status: 'effective', type: 'procedural' },
    ],
    potentialConsequences: [
      'Serious Injury or Fatality (SIF) to operating personnel',
      'Asset structural damage and environmental hydrocarbon contamination',
    ],
    whatCouldHappen:
      'IF physical and procedural barriers fail while operating near high energy, THEN an uncontrolled exposure event will occur before personnel can evacuate.',
    howToBreakTheChain: [
      'Invoke Stop-Work Authority (SWA) immediately upon noticing barrier degradation.',
      'Re-verify all physical isolation blinds, locks, and atmospheric gas detectors.',
      'Conduct a mandatory supervisor walkdown before authorization is re-granted.',
    ],
  };
}

export function generateRuleBasedWorkerCard(
  reportText: string,
  iogpRule: string,
  hazard: string,
  risk: string
): WorkerCard {
  return {
    title: `SIF ALERT: ${iogpRule.toUpperCase()} VERIFICATION REQUIRED`,
    hazard: hazard || 'Stored High Energy / Hazardous Atmosphere',
    risk: risk || 'CRITICAL',
    iogpRule,
    whatHappened:
      reportText.length > 120
        ? reportText.slice(0, 117) + '...'
        : reportText,
    whatCouldHappen:
      'Catastrophic failure of primary barriers leading to serious injury or fatality.',
    mandatoryChecks: [
      'Verify physical barrier isolation before entering work envelope.',
      'Confirm all emergency detection and stop devices are operational.',
      'Immediately stop work if any safety control appears bypassed or degraded.',
      'Review task-specific JSA (Job Safety Analysis) with crew at tool box talk.',
    ],
    languageTranslations: {
      en: {
        title: `SIF ALERT: ${iogpRule}`,
        hazard: hazard || 'High Energy Release',
        whatHappened: reportText.slice(0, 120),
        whatCouldHappen: 'Sudden release of hazardous energy resulting in fatal injury.',
        checks: [
          'Verify isolation tags and zero energy state.',
          'Confirm gas detection instruments are active.',
          'Enforce Stop-Work Authority if controls are missing.',
        ],
      },
      hi: {
        title: `गंभीर सुरक्षा चेतावनी: ${iogpRule}`,
        hazard: 'ऊर्जा का अचानक रिसाव एवं जानलेवा खतरा',
        whatHappened: 'सुरक्षा मानकों एवं नियमों का उल्लंघन करते हुए काम शुरू करने की घटना दर्ज की गई।',
        whatCouldHappen: 'अचानक दुर्घटना होने पर गंभीर शारीरिक चोट या जान जाने का खतरा।',
        checks: [
          'काम शुरू करने से पहले स्वयं सभी सुरक्षा जांच (चेकलिस्ट) पूरी करें।',
          'गैस डिटेक्टर और सुरक्षा उपकरण चालू स्थिति में होने की पुष्टि करें।',
          'खतरा महसूस होने पर तुरंत काम रोकें (Stop Work)।',
        ],
      },
      as: {
        title: `জৰুৰী সুৰক্ষা সতৰ্কবাৰ্তা: ${iogpRule}`,
        hazard: 'উচ্চ শক্তি নিৰ্গমন আৰু দুৰ্ঘটনাৰ আশংকা',
        whatHappened: 'সুৰক্ষা ব্যৱস্থা অৱমাননা কৰি কাম চলাই নিয়াৰ বাবে সতৰ্কবাৰ্তা জাৰি কৰা হৈছে।',
        whatCouldHappen: 'ভয়ানক দুৰ্ঘটনা হৈ মাৰাত্মক আঘাত বা মৃত্যু ঘটিব পাৰে।',
        checks: [
          'কাম আৰম্ভ কৰাৰ আগতে সুৰক্ষা লক আৰু সঁজুলি পৰীক্ষা কৰক।',
          'গেছ ডিটেক্টৰ আৰু এলাৰ্ম সক্ৰিয় থকাটো নিশ্চিত কৰক।',
          'বিপদ দেখিলে লগে লগে কাম বন্ধ কৰক (Stop Work)।',
        ],
      },
    },
  };
}

export async function analyzeReportWithAI(rawText: string, metadata?: {
  site?: string;
  rig_id?: string;
  location?: string;
  activity?: string;
  report_type?: SafetyReport['report_type'];
  reporter_type?: SafetyReport['reporter_type'];
}): Promise<SafetyReport> {
  const lower = rawText.toLowerCase();

  // Try Gemini if available
  if (isGeminiConnected() && ai) {
    try {
      const prompt = `You are SENTRIQ, an enterprise AI safety platform for Oil India Limited oil & gas operations.
Analyze this safety report:
"${rawText}"

Classify SIF potential, risk level, IOGP Life Saving Rules, energy source, equipment, failed barriers (hardware, procedural, human), potential consequences, explainability triggers, and a Bowtie model.
Return ONLY structured JSON conforming to the schema.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              sif_potential: { type: Type.STRING }, // "YES", "NO", "POTENTIAL"
              risk_level: { type: Type.STRING }, // "CRITICAL", "HIGH", "MEDIUM", "LOW"
              sif_confidence: { type: Type.NUMBER },
              iogp_primary: { type: Type.STRING },
              iogp_secondary: { type: Type.STRING },
              energy_source: { type: Type.STRING },
              equipment: { type: Type.STRING },
              failed_barriers: {
                type: Type.OBJECT,
                properties: {
                  hardware: { type: Type.ARRAY, items: { type: Type.STRING } },
                  procedural: { type: Type.ARRAY, items: { type: Type.STRING } },
                  human: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
              },
              potential_consequence: { type: Type.STRING },
              what_could_happen: { type: Type.STRING },
              how_to_break_chain: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: [
              'sif_potential',
              'risk_level',
              'sif_confidence',
              'iogp_primary',
              'energy_source',
              'equipment',
              'failed_barriers',
              'potential_consequence',
            ],
          },
        },
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        const xai = await explainReport(rawText);
        const bowtie = generateRuleBasedBowtie(rawText, parsed.iogp_primary || 'Energy Isolation', parsed.energy_source || 'Pressurized Hydrocarbon');
        if (parsed.what_could_happen) {
          bowtie.whatCouldHappen = parsed.what_could_happen;
        }
        if (parsed.how_to_break_chain && Array.isArray(parsed.how_to_break_chain)) {
          bowtie.howToBreakTheChain = parsed.how_to_break_chain;
        }

        const workerCard = generateRuleBasedWorkerCard(
          rawText,
          parsed.iogp_primary || 'Energy Isolation',
          parsed.energy_source || 'Hazardous Energy',
          parsed.risk_level || 'CRITICAL'
        );

        const newReport: SafetyReport = {
          report_id: `OIL-SUB-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          site: metadata?.site || 'Duliajan Field',
          rig_id: metadata?.rig_id || 'Rig OIL-14',
          location: metadata?.location || 'Zone 3 / Process Deck',
          activity: metadata?.activity || 'Maintenance / Operations',
          report_type: metadata?.report_type || 'Near Miss',
          reporter_type: metadata?.reporter_type || 'Frontline Worker',
          raw_text: rawText,
          sif_potential: (parsed.sif_potential?.toUpperCase() as SIFPotential) || 'YES',
          risk_level: (parsed.risk_level?.toUpperCase() as RiskLevel) || 'CRITICAL',
          sif_confidence: parsed.sif_confidence || 93,
          confidence_label: 'Live Gemini 3.8 Intelligence',
          iogp_primary: parsed.iogp_primary || 'Energy Isolation',
          iogp_secondary: parsed.iogp_secondary || 'Bypassing Safety Controls',
          energy_source: parsed.energy_source || 'Pressurized Hydrocarbon / Toxic Gas',
          equipment: parsed.equipment || 'High-Pressure Production Equipment',
          failed_barriers: {
            hardware: parsed.failed_barriers?.hardware || ['Gas detector offline'],
            procedural: parsed.failed_barriers?.procedural || ['LOTO verification missing'],
            human: parsed.failed_barriers?.human || ['Supervisor permitted work to continue'],
          },
          potential_consequence: parsed.potential_consequence || 'Fatal explosion or asphyxiation.',
          explainability: xai,
          bowtie,
          worker_card: workerCard,
          status: 'FLAGGED',
          human_verification_status: 'Awaiting authorized HSE verification',
        };

        reportsRepo.addReport(newReport);
        return newReport;
      }
    } catch {
      // Fall through to deterministic rule-based analysis
    }
  }

  // High-performance deterministic rule-based NLP engine (Demo Mode)
  let sifPotential: SIFPotential = 'NO';
  let riskLevel: RiskLevel = 'LOW';
  let confidence = 85;
  let primaryRule: IOGPRule = 'Work Authorization';
  let secondaryRule: IOGPRule | undefined = undefined;
  let energySource = 'Operational Mechanical Activity';
  let equipment = 'General Drilling Installation Area';
  let potentialConsequence = 'Minor operational disruption or low-severity first-aid injury.';

  const hardwareFails: string[] = [];
  const proceduralFails: string[] = [];
  const humanFails: string[] = [];

  // Rules matching
  if (lower.includes('loto') || lower.includes('isolation') || lower.includes('electric') || lower.includes('voltage') || lower.includes('breaker') || lower.includes('busbar')) {
    primaryRule = 'Energy Isolation';
    sifPotential = 'YES';
    riskLevel = 'CRITICAL';
    confidence = 94;
    energySource = lower.includes('electric') || lower.includes('volt') ? 'Electrical Energy (415V/33kV)' : 'Pressurized Hydrocarbon Gas/Oil';
    equipment = lower.includes('panel') ? 'MCC Electrical Panel' : 'Process Manifold Isolation Line';
    hardwareFails.push('Isolation valve or lock device absent');
    proceduralFails.push('Lockout/Tagout (LOTO) zero energy test skipped');
    humanFails.push('Commenced work prior to independent verification walkdown');
    potentialConsequence = 'Catastrophic energy discharge, arc flash explosion, or fatal high-pressure release.';
  } else if (lower.includes('gas') || lower.includes('detector') || lower.includes('h2s') || lower.includes('hot work') || lower.includes('welding') || lower.includes('flame')) {
    primaryRule = lower.includes('hot work') || lower.includes('weld') ? 'Hot Work' : 'Bypassing Safety Controls';
    secondaryRule = 'Energy Isolation';
    sifPotential = 'YES';
    riskLevel = 'CRITICAL';
    confidence = 92;
    energySource = 'Flammable Hydrocarbon Gas / Open Spark Ignition';
    equipment = 'Zone 3 Production Header / Gas Detector Array';
    hardwareFails.push('LEL gas detection sensor offline or out of calibration');
    proceduralFails.push('Hot work permitted without continuous gas monitoring');
    humanFails.push('Work continued despite warning flags and sensor alerts');
    potentialConsequence = 'Vapor cloud ignition and fatal flash fire explosion.';
  } else if (lower.includes('height') || lower.includes('harness') || lower.includes('monkey board') || lower.includes('scaffold') || lower.includes('fall')) {
    primaryRule = 'Working at Height';
    sifPotential = 'YES';
    riskLevel = lower.includes('90') || lower.includes('unhook') ? 'CRITICAL' : 'HIGH';
    confidence = 95;
    energySource = 'Gravitational Potential Energy (> 2 meters)';
    equipment = 'Derrick Monkey Board / Scaffold Platform';
    hardwareFails.push('Self-retracting lifeline or guardrail incomplete');
    proceduralFails.push('100% tie-off mandatory rule breached');
    humanFails.push('Worker detached lanyard while transitioning at elevation');
    potentialConsequence = 'Fatal fall from elevation onto hard steel rig structures.';
  } else if (lower.includes('lift') || lower.includes('crane') || lower.includes('sling') || lower.includes('suspended') || lower.includes('tugger') || lower.includes('wire rope')) {
    primaryRule = 'Safe Mechanical Lifting';
    secondaryRule = 'Line of Fire';
    sifPotential = 'YES';
    riskLevel = 'CRITICAL';
    confidence = 93;
    energySource = 'Gravitational Suspended Load / Tensioned Wire Elastic Energy';
    equipment = 'Mobile Crane / Air Tugger Winch / Synthetic Slings';
    hardwareFails.push('Damaged rigging sling or corroded wire rope in service');
    proceduralFails.push('Standing in drop zone / snap-back line of fire');
    humanFails.push('Guided heavy load with hands instead of non-conductive taglines');
    potentialConsequence = 'Dropped multi-ton load or recoiling cable impact causing fatal crushing.';
  } else if (lower.includes('confined') || lower.includes('tank') || lower.includes('cellar') || lower.includes('pit')) {
    primaryRule = 'Confined Space';
    sifPotential = 'YES';
    riskLevel = 'CRITICAL';
    confidence = 96;
    energySource = 'Toxic Gas (H2S) & Asphyxiating Low-Oxygen Atmosphere';
    equipment = 'Mud Tank Compartment / Wellhead Cellar';
    hardwareFails.push('Positive ventilation blower not running');
    proceduralFails.push('Confined Space Entry Permit (CSEP) missing');
    humanFails.push('Entered enclosed space without standby sentry or SCBA');
    potentialConsequence = 'Instantaneous toxic gas collapse and fatal asphyxiation.';
  } else if (lower.includes('drive') || lower.includes('speed') || lower.includes('trailer') || lower.includes('truck') || lower.includes('seatbelt') || lower.includes('ivms')) {
    primaryRule = 'Driving';
    sifPotential = 'YES';
    riskLevel = 'HIGH';
    confidence = 90;
    energySource = 'High Vehicle Kinetic Energy (Heavy Transport)';
    equipment = 'Prime Mover Trailer / Desert Transport Vehicle';
    hardwareFails.push('In-Vehicle Monitoring System (IVMS) alarm disabled');
    proceduralFails.push('Speeding beyond designated rig road limits');
    humanFails.push('Driver operated vehicle without fastening 3-point seatbelt');
    potentialConsequence = 'Rollover, cabin crush, and fatal driver ejection.';
  }

  // Ensure arrays have at least one entry
  if (hardwareFails.length === 0) hardwareFails.push('Physical warning barricade not erected');
  if (proceduralFails.length === 0) proceduralFails.push('Task safety pre-job briefing incomplete');
  if (humanFails.length === 0) humanFails.push('Task continued without positive confirmation of barrier');

  const failedBarriers: FailedBarriers = {
    hardware: hardwareFails,
    procedural: proceduralFails,
    human: humanFails,
  };

  const xai = await explainReport(rawText);
  const bowtie = generateRuleBasedBowtie(rawText, primaryRule, energySource);
  const workerCard = generateRuleBasedWorkerCard(rawText, primaryRule, energySource, riskLevel);

  const report: SafetyReport = {
    report_id: `OIL-SUB-${Date.now().toString().slice(-4)}`,
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
    site: metadata?.site || 'Duliajan Field',
    rig_id: metadata?.rig_id || 'Rig OIL-14',
    location: metadata?.location || 'Zone 3 / Process Deck',
    activity: metadata?.activity || 'Hot Work / Maintenance',
    report_type: metadata?.report_type || 'Near Miss',
    reporter_type: metadata?.reporter_type || 'Frontline Worker',
    raw_text: rawText,
    sif_potential: sifPotential,
    risk_level: riskLevel,
    sif_confidence: confidence,
    confidence_label: 'Demo AI confidence (Rule + NLP Hybrid)',
    iogp_primary: primaryRule,
    iogp_secondary: secondaryRule,
    energy_source: energySource,
    equipment,
    failed_barriers: failedBarriers,
    potential_consequence: potentialConsequence,
    explainability: xai,
    bowtie,
    worker_card: workerCard,
    status: 'FLAGGED',
    human_verification_status: 'Awaiting authorized HSE verification',
  };

  reportsRepo.addReport(report);
  return report;
}

export function generateCAPAForReport(report: SafetyReport): CAPARecord {
  const capaId = `CAPA-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;

  let title = `HSE Corrective Action for ${report.report_id} - ${report.iogp_primary}`;
  let corrective = 'Immediately stop affected work activity until positive barrier integrity is re-established.';
  let preventive = 'Update site PTW checklist, audit isolation lockboxes, and brief all shifts.';
  let responsible = 'Site HSE Supervisor & Toolpusher';
  let priority: CAPARecord['priority'] = report.risk_level === 'CRITICAL' ? 'Critical' : 'High';

  if (report.iogp_primary === 'Energy Isolation') {
    title = `LOTO Integrity Audit & Zero-Energy Verification Protocol (${report.rig_id})`;
    corrective = 'Depressurize and de-energize line; verify zero energy state on dual gauges; attach physical padlock and tag.';
    preventive = 'Mandate joint Toolpusher/HSE isolation signoff on all hazardous energy permits across asset.';
    responsible = 'Asset Mechanical Superintendent & Lead HSE Officer';
  } else if (report.iogp_primary === 'Working at Height') {
    title = `100% Tie-off Interlock & Adverse Weather Mast Safety (${report.rig_id})`;
    corrective = 'Halt elevated activity; inspect derrick safety harness and inertia reels for compliance.';
    preventive = 'Install automated twin-lanyard hook sensors; conduct refresher drill on 100% tie-off.';
    responsible = 'Drilling Superintendent & Rig HSE Officer';
  } else if (report.iogp_primary === 'Confined Space') {
    title = `Confined Space Tamper-Proof Hatch Locks & Multi-Gas Surveillance (${report.rig_id})`;
    corrective = 'Evacuate compartment; secure hatch with red lockout hasp until authorized CSEP is issued.';
    preventive = 'Recalibrate all stationary and portable 4-gas sniffers; station certified rescue sentry.';
    responsible = 'Plant Safety Manager & Shift In-Charge';
  }

  const targetDate = new Date();
  targetDate.setDate(targetDate.getDate() + (priority === 'Critical' ? 3 : 7));

  const capa: CAPARecord = {
    id: capaId,
    reportId: report.report_id,
    title,
    correctiveAction: corrective,
    preventiveAction: preventive,
    responsibleRole: responsible,
    priority,
    targetDate: targetDate.toISOString().split('T')[0],
    verificationMethod: 'Physical site walkdown, signature logbook, and calibrated instrument verification.',
    status: 'Approved',
    aiGenerated: true,
    createdAt: new Date().toISOString().split('T')[0],
  };

  reportsRepo.addCapa(capa);
  return capa;
}
