import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ReportIngestionView } from './components/ReportIngestionView';
import { SIFAnalysisView } from './components/SIFAnalysisView';
import { BowtieSimulatorView } from './components/BowtieSimulatorView';
import { WorkerSafetyCardsView } from './components/WorkerSafetyCardsView';
import { FleetImmunityView } from './components/FleetImmunityView';
import { RiskHeatmapView } from './components/RiskHeatmapView';
import { HSEActionCenterView } from './components/HSEActionCenterView';
import { ReportsDatabaseView } from './components/ReportsDatabaseView';
import { ArchitectureSettingsView } from './components/ArchitectureSettingsView';
import { LiveDemoModal } from './components/LiveDemoModal';
import { SIGNATURE_DEMO_REPORT } from './data/seedReports';
import { SafetyReport, DashboardSummary } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [currentReport, setCurrentReport] = useState<SafetyReport>(SIGNATURE_DEMO_REPORT);
  const [dashboardSummary, setDashboardSummary] = useState<DashboardSummary | null>(null);
  const [isLiveDemoOpen, setIsLiveDemoOpen] = useState<boolean>(false);
  const [isGeminiOnline, setIsGeminiOnline] = useState<boolean>(false);

  useEffect(() => {
    fetchHealth();
    fetchSummary();
  }, []);

  const fetchHealth = async () => {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      setIsGeminiOnline(Boolean(data.geminiConnected));
    } catch {
      setIsGeminiOnline(false);
    }
  };

  const fetchSummary = async () => {
    try {
      const res = await fetch('/api/dashboard/summary');
      const data = await res.json();
      setDashboardSummary(data);
    } catch {
      // fallback
    }
  };

  const handleSelectReport = (report: SafetyReport) => {
    setCurrentReport(report);
    setActiveTab('analysis');
  };

  const handleNavigateToBowtie = (report: SafetyReport) => {
    setCurrentReport(report);
    setActiveTab('bowtie');
  };

  const handleReportAnalyzed = (report: SafetyReport) => {
    setCurrentReport(report);
    fetchSummary(); // refresh counts
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-900 font-sans selection:bg-cyan-500 selection:text-white">
      {/* Persistent Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRunLiveDemo={() => setIsLiveDemoOpen(true)}
        isGeminiConnected={isGeminiOnline}
        totalAlertsCount={dashboardSummary?.activeFleetAlertsCount || 12}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <DashboardView
            summary={dashboardSummary}
            onSelectReport={handleSelectReport}
            onNavigate={setActiveTab}
            onRunSignatureDemo={() => setIsLiveDemoOpen(true)}
          />
        )}

        {activeTab === 'ingest' && (
          <ReportIngestionView
            onReportAnalyzed={handleReportAnalyzed}
            onNavigateToAnalysis={() => setActiveTab('analysis')}
          />
        )}

        {activeTab === 'analysis' && (
          <SIFAnalysisView
            report={currentReport}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'bowtie' && (
          <BowtieSimulatorView
            report={currentReport}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'cards' && (
          <WorkerSafetyCardsView
            report={currentReport}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'fleet' && (
          <FleetImmunityView
            currentReport={currentReport}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'heatmap' && (
          <RiskHeatmapView
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'actions' && (
          <HSEActionCenterView
            onSelectReport={handleSelectReport}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'database' && (
          <ReportsDatabaseView
            onSelectReport={handleSelectReport}
            onNavigateToBowtie={handleNavigateToBowtie}
          />
        )}

        {activeTab === 'settings' && (
          <ArchitectureSettingsView />
        )}
      </main>

      {/* Guided 10-Step Signature Live Demo Modal */}
      <LiveDemoModal
        isOpen={isLiveDemoOpen}
        onClose={() => setIsLiveDemoOpen(false)}
        onSelectTab={setActiveTab}
        onLoadReport={(rep) => setCurrentReport(rep)}
      />

      {/* Persistent Enterprise Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 text-xs print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-white">SENTRIQ</span>
            <span>•</span>
            <span>Safety AI for Fatality Elimination</span>
            <span>•</span>
            <span className="text-cyan-400">SIH 2026 Problem Statement 26165</span>
          </div>

          <div className="text-slate-500 text-center sm:text-right">
            <span>Prototype for Oil India Limited • Synthetic Data Demonstration</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
