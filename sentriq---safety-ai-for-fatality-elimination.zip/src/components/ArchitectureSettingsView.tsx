import React from 'react';
import {
  Server,
  Database,
  Compass,
  Layers,
  Code2,
  Cpu,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';

export const ArchitectureSettingsView: React.FC = () => {
  const iogpRules = [
    { name: 'Energy Isolation', desc: 'Verify isolation and zero energy state before work begins.' },
    { name: 'Bypassing Safety Controls', desc: 'Obtain authorization before overriding or disabling safety devices.' },
    { name: 'Confined Space', desc: 'Obtain authorization before entering a confined space.' },
    { name: 'Driving', desc: 'Do not exceed speed limits, wear seatbelts, and avoid mobile devices while driving.' },
    { name: 'Hot Work', desc: 'Identify and control flammables before sparking or applying open heat.' },
    { name: 'Line of Fire', desc: 'Keep yourself and others out of the path of moving objects, pressure lines, and drop zones.' },
    { name: 'Safe Mechanical Lifting', desc: 'Plan lifting operations and control the area under suspended loads.' },
    { name: 'Work Authorization', desc: 'Work with a valid work permit when required and confirm hazard controls.' },
    { name: 'Working at Height', desc: 'Protect yourself against a fall when working at elevation (> 1.8m).' },
  ];

  const apiEndpoints = [
    { method: 'POST', path: '/api/reports/analyze', desc: 'Analyzes raw observation text with SIF, IOGP, XAI, and Bowtie models.' },
    { method: 'GET', path: '/api/reports', desc: 'Queries and filters the safety reports repository.' },
    { method: 'GET', path: '/api/reports/:id', desc: 'Fetches single report dossier by report_id.' },
    { method: 'GET', path: '/api/dashboard/summary', desc: 'Calculates executive KPIs, 7-day trend, and IOGP distributions.' },
    { method: 'GET', path: '/api/heatmap', desc: 'Spatial risk density by asset and rig installation.' },
    { method: 'POST', path: '/api/bowtie/generate', desc: 'Synthesizes dynamic Bowtie barrier threats, top event, and mitigations.' },
    { method: 'POST', path: '/api/cards/generate', desc: 'Generates multilingual visual toolbox talk briefing cards.' },
    { method: 'POST', path: '/api/capa/generate', desc: 'Generates AI-assisted corrective and preventive actions.' },
    { method: 'GET', path: '/api/fleet/similar', desc: 'Swarm similarity search for active operations across sister rigs.' },
    { method: 'POST', path: '/api/voice/transcribe', desc: 'Normalizes spoken worker field dialect into structured HSE text.' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2">
          <Server className="h-6 w-6 text-cyan-600" />
          <h1 className="text-xl font-bold text-slate-900">System Architecture & Technical Specifications</h1>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-100 text-cyan-800 uppercase font-mono">
            SIH 2026 • PS 26165
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Technical design specifications, ASCII architecture diagrams, API schemas, and industry standard alignments.
        </p>
      </div>

      {/* ASCII Architecture Flow Diagram (Prompt requirement #23) */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="h-5 w-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-cyan-300 uppercase tracking-wide">
              SENTRIQ INTELLIGENCE PIPELINE ARCHITECTURE
            </h2>
          </div>
          <span className="text-[10px] font-mono text-slate-400">ASCII ARCHITECTURE (SECTION 23)</span>
        </div>

        <pre className="font-mono text-[11px] leading-relaxed text-cyan-200/90 p-4 bg-slate-950 rounded-xl overflow-x-auto border border-slate-800">
{`                ┌──────────────────────────┐
                │ Worker / HSE Officer     │
                │ Text / Voice / Web       │
                └────────────┬─────────────┘
                             ↓
                ┌──────────────────────────┐
                │ Report Ingestion Layer   │
                └────────────┬─────────────┘
                             ↓
                ┌──────────────────────────┐
                │ Sentriq AI/NLP Engine    │
                │ SIF + IOGP + NER         │
                └────────────┬─────────────┘
                             ↓
        ┌────────────────────┼────────────────────┐
        ↓                    ↓                    ↓
      XAI                 Bowtie             Pattern Mining
  (SHAP-style)       (Threat-Consequence)     (Swarm Vector)
        ↓                    ↓                    ↓
        └────────────────────┼────────────────────┘
                             ↓
                ┌──────────────────────────┐
                │ HSE Intelligence Layer   │
                └────────────┬─────────────┘
                             ↓
        ┌────────────────────┼────────────────────┐
        ↓                    ↓                    ↓
    Dashboard          Worker Cards        Fleet Immunity
  (Spatial Heatmap)    (Multilingual)        (Cross-Site)
        ↓                    ↓                    ↓
       HSE              Frontline            Cross-Site
      Action             Safety              Alerts`}
        </pre>
      </div>

      {/* SIH 2026 Problem Statement Context Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-blue-600" />
          <h2 className="text-base font-bold text-slate-900">
            SIH 2026 – Problem Statement 26165 – Oil India Limited
          </h2>
        </div>
        <p className="text-xs text-slate-700 leading-relaxed">
          <strong>The Challenge:</strong> Oil & Gas operations generate vast volumes of qualitative, unstructured observation cards, near-miss reports, and incident logs. Most severe incidents (Serious Injuries and Fatalities - SIF) are preceded by precursor events that were logged as low-severity or near misses but contained high-energy potential with compromised barrier controls.
        </p>
        <p className="text-xs text-slate-700 leading-relaxed">
          <strong>Sentriq Solution:</strong> An explainable NLP intelligence platform that classifies SIF potential, maps IOGP Life-Saving Rules, isolates barrier failures across hardware/procedural/human dimensions, generates interactive Bowtie simulations, and broadcasts fleet immunity alerts to sister rigs before an incident recurs.
        </p>
      </div>

      {/* IOGP 9 Life-Saving Rules Reference */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Compass className="h-5 w-5 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">IOGP 9 Life-Saving Rules Reference</h2>
          </div>
          <span className="text-[10px] font-bold text-slate-500 font-mono">IOGP Report 459 Standard</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {iogpRules.map((rule, idx) => (
            <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
              <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-cyan-600" />
                <span>{rule.name}</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-normal">{rule.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* API Reference Table (Section 18) */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">REST API Interface Documentation (Section 18)</h2>
          </div>
          <span className="text-xs font-mono text-slate-500">Express / TypeScript</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-2.5 px-3">Method</th>
                <th className="py-2.5 px-3">Route Endpoint</th>
                <th className="py-2.5 px-3">Description & Payload</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {apiEndpoints.map((ep, idx) => (
                <tr key={idx} className="hover:bg-slate-50/80">
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        ep.method === 'POST' ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {ep.method}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-bold text-slate-800">{ep.path}</td>
                  <td className="py-2.5 px-3 font-sans text-slate-600">{ep.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
