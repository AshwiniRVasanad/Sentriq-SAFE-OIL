import React, { useState } from 'react';
import {
  X,
  Play,
  ArrowRight,
  ArrowLeft,
  ShieldAlert,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Compass,
  Users,
  Radio,
  FileCheck,
  Check,
  ExternalLink,
} from 'lucide-react';
import { SIGNATURE_DEMO_REPORT } from '../data/seedReports';
import { SafetyReport } from '../types';

interface LiveDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: string) => void;
  onLoadReport: (report: SafetyReport) => void;
}

export const LiveDemoModal: React.FC<LiveDemoModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onLoadReport,
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      title: 'Raw Unstructured Safety Report Ingestion',
      subtitle: 'Field observation submitted via frontline mobile or web portal',
      tabTarget: 'ingest',
      icon: Flame,
      color: 'text-amber-500',
      content: (
        <div className="space-y-3">
          <div className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-sm border border-slate-700">
            <div className="text-xs text-cyan-400 mb-1 font-sans font-semibold">
              ORIGINAL FIELD REPORT (OIL-DUL-2026-0842 • Rig OIL-14, Duliajan Field)
            </div>
            &ldquo;{SIGNATURE_DEMO_REPORT.raw_text}&rdquo;
          </div>
          <p className="text-xs text-slate-400">
            Traditional HSE systems store this in a static database as text. Sentriq immediately pipes it into the AI/NLP
            intelligence pipeline.
          </p>
        </div>
      ),
    },
    {
      step: 2,
      title: 'AI Entity Extraction & Energy Source Mapping',
      subtitle: 'Named entity recognition extracts equipment, hazardous energy, and location',
      tabTarget: 'analysis',
      icon: ShieldAlert,
      color: 'text-cyan-500',
      content: (
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <span className="text-slate-500 block uppercase font-medium">Identified Energy Source</span>
            <span className="font-bold text-slate-900 text-sm mt-0.5 block">{SIGNATURE_DEMO_REPORT.energy_source}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <span className="text-slate-500 block uppercase font-medium">Critical Equipment</span>
            <span className="font-bold text-slate-900 text-sm mt-0.5 block">{SIGNATURE_DEMO_REPORT.equipment}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <span className="text-slate-500 block uppercase font-medium">Classified Area</span>
            <span className="font-bold text-slate-900 text-sm mt-0.5 block">Zone 3 (Flammable Gas Envelope)</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <span className="text-slate-500 block uppercase font-medium">Activity Category</span>
            <span className="font-bold text-slate-900 text-sm mt-0.5 block">{SIGNATURE_DEMO_REPORT.activity}</span>
          </div>
        </div>
      ),
    },
    {
      step: 3,
      title: 'SIF Precursor Classification',
      subtitle: 'Assessing exposure to high-energy release with compromised barriers',
      tabTarget: 'analysis',
      icon: AlertTriangle,
      color: 'text-rose-500',
      content: (
        <div className="bg-rose-50 border-2 border-rose-400 p-4 rounded-xl text-center">
          <div className="text-xs uppercase font-extrabold tracking-wider text-rose-600 mb-1">
            SIF Potential Detected
          </div>
          <div className="text-3xl font-black text-rose-700">YES — CRITICAL SIF RISK</div>
          <div className="mt-2 text-xs font-semibold text-rose-800 bg-white/70 inline-block px-3 py-1 rounded-full border border-rose-300">
            {SIGNATURE_DEMO_REPORT.confidence_label}: {SIGNATURE_DEMO_REPORT.sif_confidence}%
          </div>
          <p className="mt-2 text-xs text-rose-900 font-medium">
            Active ignition source combined with unverified hydrocarbon barrier and non-functioning atmospheric monitor.
          </p>
        </div>
      ),
    },
    {
      step: 4,
      title: 'IOGP Life-Saving Rules Mapping',
      subtitle: 'Standardized industry rules mapped automatically',
      tabTarget: 'analysis',
      icon: ShieldAlert,
      color: 'text-blue-500',
      content: (
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="border border-blue-200 bg-blue-50/60 p-3.5 rounded-lg">
            <span className="text-blue-600 font-bold block uppercase text-[10px]">Primary Life-Saving Rule</span>
            <div className="text-base font-extrabold text-blue-900 mt-0.5">{SIGNATURE_DEMO_REPORT.iogp_primary}</div>
            <p className="text-blue-800 text-[11px] mt-1">Verify isolation and zero energy state before work begins.</p>
          </div>
          <div className="border border-amber-200 bg-amber-50/60 p-3.5 rounded-lg">
            <span className="text-amber-600 font-bold block uppercase text-[10px]">Secondary Life-Saving Rule</span>
            <div className="text-base font-extrabold text-amber-900 mt-0.5">{SIGNATURE_DEMO_REPORT.iogp_secondary}</div>
            <p className="text-amber-800 text-[11px] mt-1">Obtain authorization before overriding or disabling safety devices.</p>
          </div>
        </div>
      ),
    },
    {
      step: 5,
      title: 'Explainable AI (XAI) Phrase Highlighting',
      subtitle: 'SHAP-style multi-token feature attribution explaining why the model flagged this report',
      tabTarget: 'analysis',
      icon: Flame,
      color: 'text-purple-500',
      content: (
        <div className="space-y-3">
          <div className="p-3.5 rounded-lg bg-slate-900 text-white text-sm leading-relaxed border border-slate-700">
            During{' '}
            <span className="bg-amber-500/30 text-amber-300 font-semibold px-1 rounded border border-amber-400">
              hot work
            </span>{' '}
            in{' '}
            <span className="bg-blue-500/30 text-blue-300 px-1 rounded border border-blue-400">Zone 3</span>, the{' '}
            <span className="bg-rose-600/40 text-rose-200 font-bold px-1 rounded border border-rose-400">
              gas detector was offline
            </span>{' '}
            and the crew started work{' '}
            <span className="bg-rose-600/40 text-rose-200 font-bold px-1 rounded border border-rose-400">
              before LOTO verification
            </span>
            . Supervisor was informed but{' '}
            <span className="bg-amber-500/30 text-amber-300 font-semibold px-1 rounded border border-amber-400">
              work continued
            </span>
            .
          </div>
          <div className="flex gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded bg-rose-500"></span>
              <span className="text-slate-600 font-medium">Critical Trigger</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded bg-amber-500"></span>
              <span className="text-slate-600 font-medium">Risk-Related Phrase</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded bg-blue-500"></span>
              <span className="text-slate-600 font-medium">Contextual Phrase</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      step: 6,
      title: 'Failed Barrier Triad Identification',
      subtitle: 'Categorizing barrier breakdowns across hardware, procedure, and human action',
      tabTarget: 'analysis',
      icon: AlertTriangle,
      color: 'text-amber-500',
      content: (
        <div className="grid grid-cols-3 gap-2.5 text-xs">
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <span className="font-bold text-red-700 block mb-1">Hardware Barrier</span>
            <ul className="list-disc pl-3 text-slate-700 space-y-1 text-[11px]">
              {SIGNATURE_DEMO_REPORT.failed_barriers.hardware.map((b, i) => (
                <li key={i}>{b}</li>
              ))}
            </ul>
          </div>
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <span className="font-bold text-amber-700 block mb-1">Procedural Barrier</span>
            <ul className="list-disc pl-3 text-slate-700 space-y-1 text-[11px]">
              {SIGNATURE_DEMO_REPORT.failed_barriers.procedural.map((b, i) => (
                <li key={i}>{b}</li>
              ))}
            </ul>
          </div>
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="font-bold text-blue-700 block mb-1">Human / Administrative</span>
            <ul className="list-disc pl-3 text-slate-700 space-y-1 text-[11px]">
              {SIGNATURE_DEMO_REPORT.failed_barriers.human.map((b, i) => (
                <li key={i}>{b}</li>
              ))}
            </ul>
          </div>
        </div>
      ),
    },
    {
      step: 7,
      title: 'Bowtie Simulator: "What Could Happen?"',
      subtitle: 'Dynamic scenario simulation showing the chain reaction from threat to consequence',
      tabTarget: 'bowtie',
      icon: Compass,
      color: 'text-cyan-600',
      content: (
        <div className="space-y-3">
          <div className="p-3.5 bg-slate-900 text-white rounded-lg text-xs leading-relaxed border-l-4 border-rose-500">
            <span className="text-cyan-400 font-bold block mb-1">WHAT COULD HAPPEN?</span>
            {SIGNATURE_DEMO_REPORT.bowtie.whatCouldHappen}
          </div>
          <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-lg text-xs text-emerald-900">
            <strong className="block text-emerald-800">How to Break the Chain:</strong>
            {SIGNATURE_DEMO_REPORT.bowtie.howToBreakTheChain[0]}
          </div>
        </div>
      ),
    },
    {
      step: 8,
      title: 'Multilingual Frontline Worker Safety Card',
      subtitle: 'Instant translation into English, Hindi, and Assamese for pre-shift toolbox talks',
      tabTarget: 'cards',
      icon: Users,
      color: 'text-emerald-600',
      content: (
        <div className="bg-amber-50/80 border-2 border-amber-300 p-3.5 rounded-xl space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="font-extrabold text-amber-900 uppercase">TODAY&apos;S SAFETY ALERT</span>
            <span className="px-2 py-0.5 rounded bg-amber-200 font-bold text-amber-800 text-[10px]">
              MULTILINGUAL BRIEFING
            </span>
          </div>
          <div className="text-xs text-slate-800">
            <p className="font-bold text-slate-900">{SIGNATURE_DEMO_REPORT.worker_card.title}</p>
            <p className="mt-1 text-[11px] text-slate-600">
              <strong>Mandatory check:</strong> {SIGNATURE_DEMO_REPORT.worker_card.mandatoryChecks[0]}
            </p>
          </div>
          <div className="flex gap-2 pt-1 border-t border-amber-200 text-[10px] text-slate-600 font-semibold">
            <span>✓ English</span>
            <span>✓ हिन्दी (Hindi)</span>
            <span>✓ অসমীয়া (Assamese)</span>
          </div>
        </div>
      ),
    },
    {
      step: 9,
      title: 'Fleet Immunity Swarm Intelligence',
      subtitle: 'Searching synthetic enterprise database for similar high-risk active operations across rigs',
      tabTarget: 'fleet',
      icon: Radio,
      color: 'text-indigo-600',
      content: (
        <div className="space-y-2">
          <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-lg text-xs">
            <div className="font-bold text-indigo-900">3 SIMILAR ACTIVE OPERATIONS DETECTED IN FLEET</div>
            <div className="mt-1 space-y-1 text-[11px] text-indigo-800">
              <div className="flex justify-between">
                <span>Rig 07 – Moran (Hot Work / Manifold)</span>
                <span className="font-bold text-indigo-600">92% Similarity DEMO</span>
              </div>
              <div className="flex justify-between">
                <span>Rig 21 – Digboi (Drilling / High Pressure)</span>
                <span className="font-bold text-indigo-600">86% Similarity DEMO</span>
              </div>
              <div className="flex justify-between">
                <span>Rig 03 – Rajasthan (Wellhead Servicing)</span>
                <span className="font-bold text-indigo-600">82% Similarity DEMO</span>
              </div>
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            Sentriq automatically transmits cross-site fleet immunity alerts so sister rigs can verify their barriers before an incident repeats.
          </p>
        </div>
      ),
    },
    {
      step: 10,
      title: 'Conditional Human-in-the-Loop Safety Gate & CAPA',
      subtitle: 'Decision-support governance: Stop-work recommendation awaiting authorized human verification',
      tabTarget: 'actions',
      icon: FileCheck,
      color: 'text-emerald-500',
      content: (
        <div className="space-y-3">
          <div className="bg-rose-50 border-2 border-rose-300 p-3 rounded-lg text-xs text-rose-900">
            <span className="font-bold block uppercase text-[10px] text-rose-700">Governance Gate</span>
            <div className="font-black text-sm text-rose-950 mt-0.5">STOP-WORK RECOMMENDATION</div>
            <div className="text-[11px] text-rose-700 mt-1">
              Status: <strong>Awaiting authorized HSE verification</strong> (AI does not directly control physical machinery).
            </div>
          </div>
          <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-lg text-[11px] text-slate-700">
            <strong>Automated CAPA Draft:</strong> Stop affected hot work, conduct double-block-and-bleed verification, and recalibrate LEL sensors.
          </div>
        </div>
      ),
    },
  ];

  const current = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Completed tour! Load into analysis
      onLoadReport(SIGNATURE_DEMO_REPORT);
      onSelectTab('analysis');
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleJumpToAppTab = (tabId: string) => {
    onLoadReport(SIGNATURE_DEMO_REPORT);
    onSelectTab(tabId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping"></span>
            <span className="font-extrabold text-sm tracking-wide text-cyan-400 uppercase">
              Sentriq End-to-End Live Demonstration
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="bg-slate-100 px-6 py-2 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            {steps.map((s, idx) => (
              <button
                key={s.step}
                onClick={() => setCurrentStep(idx)}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === currentStep
                    ? 'w-7 bg-cyan-600'
                    : idx < currentStep
                    ? 'w-3 bg-emerald-500'
                    : 'w-3 bg-slate-300'
                }`}
                title={`Step ${s.step}: ${s.title}`}
              />
            ))}
          </div>
          <span className="text-xs font-semibold text-slate-500 ml-4 whitespace-nowrap">
            Step {currentStep + 1} of {steps.length}
          </span>
        </div>

        {/* Step Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
              <span>Sequence Step {current.step}</span>
              <span>•</span>
              <span>{current.tabTarget.toUpperCase()} MODULE</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mt-1">{current.title}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{current.subtitle}</p>
          </div>

          <div className="pt-2">{current.content}</div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={() => handleJumpToAppTab(current.tabTarget)}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-cyan-700 font-semibold cursor-pointer transition-colors"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            <span>Open in {current.tabTarget.toUpperCase()}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              disabled={currentStep === 0}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border ${
                currentStep === 0
                  ? 'border-slate-200 text-slate-300 cursor-not-allowed'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer'
              }`}
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Back</span>
            </button>

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/30 cursor-pointer transition-colors"
            >
              <span>{currentStep === steps.length - 1 ? 'Finish & Explore App' : 'Next Step'}</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
