import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  Filter,
  Download,
  ChevronRight,
  ShieldAlert,
  Compass,
  ArrowUpDown,
  ExternalLink,
} from 'lucide-react';
import { SafetyReport } from '../types';

interface ReportsDatabaseViewProps {
  onSelectReport: (report: SafetyReport) => void;
  onNavigateToBowtie: (report: SafetyReport) => void;
}

export const ReportsDatabaseView: React.FC<ReportsDatabaseViewProps> = ({
  onSelectReport,
  onNavigateToBowtie,
}) => {
  const [reports, setReports] = useState<SafetyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sifFilter, setSifFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');
  const [siteFilter, setSiteFilter] = useState('all');

  useEffect(() => {
    fetchReports();
  }, [searchQuery, sifFilter, riskFilter, siteFilter]);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.append('search', searchQuery);
      if (sifFilter !== 'all') params.append('sif', sifFilter);
      if (riskFilter !== 'all') params.append('risk', riskFilter);
      if (siteFilter !== 'all') params.append('site', siteFilter);

      const res = await fetch(`/api/reports?${params.toString()}`);
      const data = await res.json();
      setReports(data);
      setLoading(false);
    } catch {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'report_id',
      'timestamp',
      'site',
      'rig_id',
      'location',
      'activity',
      'report_type',
      'reporter_type',
      'raw_text',
      'sif_potential',
      'risk_level',
      'sif_confidence',
      'iogp_primary',
      'energy_source',
      'equipment',
      'status',
    ];

    const rows = reports.map((r) => [
      `"${r.report_id}"`,
      `"${r.timestamp}"`,
      `"${r.site}"`,
      `"${r.rig_id}"`,
      `"${r.location}"`,
      `"${r.activity}"`,
      `"${r.report_type}"`,
      `"${r.reporter_type}"`,
      `"${r.raw_text.replace(/"/g, '""')}"`,
      `"${r.sif_potential}"`,
      `"${r.risk_level}"`,
      r.sif_confidence,
      `"${r.iogp_primary}"`,
      `"${r.energy_source}"`,
      `"${r.equipment}"`,
      `"${r.status}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SENTRIQ_SYNTHETIC_REPORTS_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-cyan-600" />
            <h1 className="text-xl font-bold text-slate-900">Synthetic Safety Reports Repository</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
              DATABASE ABSTRACTION
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Browse, filter, and inspect {reports.length} seeded multi-site oilfield safety observations spanning drilling, workover, and production.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-colors"
        >
          <Download className="h-3.5 w-3.5 text-cyan-400" />
          <span>Export Filtered to CSV</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Search Input */}
        <div className="flex-1 min-w-[240px] relative">
          <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search report narrative, equipment, energy source, or ID..."
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 font-medium text-slate-800 focus:ring-2 focus:ring-cyan-500"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={sifFilter}
            onChange={(e) => setSifFilter(e.target.value)}
            className="p-2 rounded-lg border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="all">SIF: All</option>
            <option value="YES">SIF: YES</option>
            <option value="NO">SIF: NO</option>
          </select>

          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="p-2 rounded-lg border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="all">Risk: All</option>
            <option value="CRITICAL">Risk: CRITICAL</option>
            <option value="HIGH">Risk: HIGH</option>
            <option value="MEDIUM">Risk: MEDIUM</option>
            <option value="LOW">Risk: LOW</option>
          </select>

          <select
            value={siteFilter}
            onChange={(e) => setSiteFilter(e.target.value)}
            className="p-2 rounded-lg border border-slate-200 bg-white font-medium text-slate-700"
          >
            <option value="all">Site: All</option>
            <option value="Duliajan">Duliajan Field</option>
            <option value="Digboi">Digboi Field</option>
            <option value="Moran">Moran Field</option>
            <option value="Rajasthan">Rajasthan Asset</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-600 mx-auto"></div>
            <p className="text-xs text-slate-400 mt-2">Loading safety reports...</p>
          </div>
        ) : reports.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            No matching reports found for the selected query filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <th className="py-3 px-4">Report ID</th>
                  <th className="py-3 px-4">Date / Time</th>
                  <th className="py-3 px-4">Asset / Rig</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Observation Narrative</th>
                  <th className="py-3 px-4">Primary IOGP Rule</th>
                  <th className="py-3 px-4">SIF Potential</th>
                  <th className="py-3 px-4">Risk Level</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reports.map((report) => (
                  <tr key={report.report_id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-cyan-700">{report.report_id}</td>
                    <td className="py-3 px-4 text-slate-500 font-mono whitespace-nowrap">
                      {report.timestamp.slice(0, 16)}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                      {report.site} ({report.rig_id})
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-medium whitespace-nowrap">
                      {report.report_type}
                    </td>
                    <td className="py-3 px-4 text-slate-700 max-w-sm truncate" title={report.raw_text}>
                      {report.raw_text}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
                        {report.iogp_primary}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded font-black text-[10px] ${
                          report.sif_potential === 'YES'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {report.sif_potential}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                          report.risk_level === 'CRITICAL'
                            ? 'bg-rose-100 text-rose-800'
                            : report.risk_level === 'HIGH'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {report.risk_level}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                      <button
                        onClick={() => onSelectReport(report)}
                        className="px-2.5 py-1 bg-cyan-50 hover:bg-cyan-100 text-cyan-700 font-semibold rounded text-xs border border-cyan-200 cursor-pointer"
                      >
                        SIF AI Dossier
                      </button>
                      <button
                        onClick={() => onNavigateToBowtie(report)}
                        className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded text-xs border border-slate-300 cursor-pointer"
                      >
                        Bowtie
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
