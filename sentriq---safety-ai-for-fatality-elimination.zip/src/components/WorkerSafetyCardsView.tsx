import React, { useState } from 'react';
import {
  Users,
  Volume2,
  VolumeX,
  Download,
  Share2,
  Printer,
  Sparkles,
  ShieldAlert,
  Compass,
  CheckCircle2,
  Languages,
  ArrowRight,
  Flame,
} from 'lucide-react';
import { SafetyReport, LanguageCardContent } from '../types';

interface WorkerSafetyCardsViewProps {
  report: SafetyReport;
  onNavigate: (tab: string) => void;
}

export const WorkerSafetyCardsView: React.FC<WorkerSafetyCardsViewProps> = ({
  report,
  onNavigate,
}) => {
  const [selectedLang, setSelectedLang] = useState<'en' | 'hi' | 'as'>('en');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const cardData = report.worker_card;
  const langData: LanguageCardContent =
    cardData.languageTranslations[selectedLang] || cardData.languageTranslations.en;

  const handleSpeak = () => {
    if (isPlayingAudio) {
      window.speechSynthesis?.cancel();
      setIsPlayingAudio(false);
      return;
    }

    if (!window.speechSynthesis) {
      alert('Speech synthesis is not supported on this browser.');
      return;
    }

    const textToRead = `${langData.title}. Hazard: ${langData.hazard}. What happened: ${langData.whatHappened}. What could happen: ${langData.whatCouldHappen}. Mandatory checks before starting work: ${langData.checks.join('. ')}`;

    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = selectedLang === 'hi' ? 'hi-IN' : 'en-US';
    utterance.rate = 0.95;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate text/JSON file download for demo
    const element = document.createElement('a');
    const file = new Blob(
      [
        `=======================================================\nSENTRIQ FRONTLINE TOOLBOX TALK CARD\nSite: ${report.site} | Rig: ${report.rig_id}\nDate: ${report.timestamp}\n=======================================================\n${langData.title}\nHazard: ${langData.hazard}\nRisk Level: ${cardData.risk}\nIOGP Rule: ${cardData.iogpRule}\n\nWHAT HAPPENED:\n${langData.whatHappened}\n\nWHAT COULD HAPPEN:\n${langData.whatCouldHappen}\n\nMANDATORY BEFORE-WORK CHECKS:\n${langData.checks.map((c, i) => `[ ] ${i + 1}. ${c}`).join('\n')}\n\n(AI-generated demonstration briefing card for SIH 2026)\n=======================================================`,
      ],
      { type: 'text/plain' }
    );
    element.href = URL.createObjectURL(file);
    element.download = `SENTRIQ-TOOLBOX-${report.report_id}-${selectedLang}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6 text-cyan-600" />
            <h1 className="text-xl font-bold text-slate-900">Frontline Visual Toolbox Talk Cards</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 uppercase">
              Worker-Centric AI
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Converting high-dimensional NLP SIF intelligence into simple, actionable visual safety briefings in frontline languages.
          </p>
        </div>

        {/* Language & Audio Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Language Selector */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setSelectedLang('en')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                selectedLang === 'en'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setSelectedLang('hi')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                selectedLang === 'hi'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              हिन्दी (Hindi)
            </button>
            <button
              onClick={() => setSelectedLang('as')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                selectedLang === 'as'
                  ? 'bg-white text-slate-900 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              অসমীয়া (Assamese)
            </button>
          </div>

          {/* Audio Read-Aloud */}
          <button
            onClick={handleSpeak}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
              isPlayingAudio
                ? 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse'
                : 'bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border-cyan-200'
            }`}
          >
            {isPlayingAudio ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            <span>{isPlayingAudio ? 'Stop Voice' : 'Audio Briefing'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/30 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Card</span>
          </button>
        </div>
      </div>

      {/* The Printable Visual Toolbox Card */}
      <div className="max-w-3xl mx-auto bg-white rounded-3xl border-4 border-amber-400 shadow-2xl overflow-hidden print:border-2 print:shadow-none">
        {/* Card Header Strip */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 p-6 flex flex-wrap items-center justify-between gap-4 border-b-2 border-amber-600/30">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-slate-950 text-amber-300 text-[10px] font-mono font-black px-2 py-0.5 rounded tracking-widest uppercase">
                TODAY&apos;S PRE-JOB TOOLBOX TALK
              </span>
              <span className="text-xs font-bold text-slate-900">
                {report.site} • {report.rig_id}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-950 mt-1 leading-tight tracking-tight">
              {langData.title}
            </h2>
          </div>

          <div className="text-right">
            <span
              className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                cardData.risk === 'CRITICAL'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'bg-amber-900 text-white shadow-md'
              }`}
            >
              RISK: {cardData.risk}
            </span>
            <div className="text-[10px] font-bold text-slate-900 mt-1">
              RULE: {cardData.iogpRule}
            </div>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Top Triad: Hazard + What Happened + What Could Happen */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* What Happened */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1">
                WHAT HAPPENED (Incident Observation)
              </span>
              <p className="text-sm font-bold text-slate-800 leading-snug">
                {langData.whatHappened}
              </p>
              <div className="mt-2 text-xs text-slate-500">
                Identified Hazard: <strong className="text-slate-700">{langData.hazard}</strong>
              </div>
            </div>

            {/* What Could Happen */}
            <div className="bg-rose-50 p-4 rounded-2xl border-2 border-rose-300">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-700 block mb-1">
                WHAT COULD HAPPEN (Worst Case Scenario)
              </span>
              <p className="text-sm font-black text-rose-950 leading-snug">
                {langData.whatCouldHappen}
              </p>
              <div className="mt-2 text-xs text-rose-800 font-medium">
                Failure mechanism: Uncontained high-energy breach.
              </div>
            </div>
          </div>

          {/* Mandatory Checklist Before Starting Work */}
          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-6 rounded-2xl border-2 border-emerald-300 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-6 w-6 text-emerald-600" />
                <h3 className="text-base font-black text-emerald-950 uppercase tracking-wide">
                  BEFORE STARTING WORK: MANDATORY VERIFICATIONS
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200 text-emerald-800 font-mono">
                100% COMPLIANCE
              </span>
            </div>

            <div className="space-y-2.5">
              {langData.checks.map((check, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 bg-white p-3 rounded-xl border border-emerald-200 shadow-sm"
                >
                  <div className="h-5 w-5 rounded-md border-2 border-emerald-500 flex items-center justify-center font-bold text-emerald-700 text-xs mt-0.5 shrink-0">
                    ✓
                  </div>
                  <span className="text-sm font-bold text-slate-800 leading-snug">{check}</span>
                </div>
              ))}
            </div>
          </div>

          {/* IOGP Life-Saving Rule Badge & Sign-off Stamp */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-200 text-xs">
            <div className="flex items-center gap-2">
              <Compass className="h-5 w-5 text-cyan-700" />
              <span className="font-bold text-slate-800">
                IOGP Life-Saving Rule: <span className="text-blue-700">{cardData.iogpRule}</span>
              </span>
            </div>

            <div className="flex items-center gap-4 text-slate-500 font-mono text-[11px]">
              <div>
                Supervisor Sign-off: <span className="underline font-bold text-slate-800">________________</span>
              </div>
              <div>
                Crew Count: <span className="underline font-bold text-slate-800">_____</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card Footer Banner */}
        <div className="bg-slate-100 px-6 py-2.5 border-t border-slate-200 text-center text-[10px] text-slate-500 font-mono">
          AI-generated demonstration card • SENTRIQ SIH 2026 • Oil India Limited Prototype • Always exercise Stop-Work Authority
        </div>
      </div>

      {/* Navigation Footer */}
      <div className="flex justify-between items-center text-xs text-slate-500 pt-2">
        <span>Toolbox Talk Card generated dynamically from SIF Intelligence Dossier</span>
        <button
          onClick={() => onNavigate('fleet')}
          className="font-bold text-cyan-700 hover:text-cyan-900 underline flex items-center gap-1 cursor-pointer"
        >
          <span>Search Cross-Rig Fleet Immunity →</span>
        </button>
      </div>
    </div>
  );
};
