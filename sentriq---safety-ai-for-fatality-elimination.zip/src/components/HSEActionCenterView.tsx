import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  ShieldAlert,
  FileCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Download,
  Printer,
  ChevronRight,
  UserCheck,
  Compass,
} from 'lucide-react';
import { SafetyReport, CAPARecord } from '../types';

interface HSEActionCenterViewProps {
  onSelectReport: (report: SafetyReport) => void;
  onNavigate: (tab: string) => void;
}

export const HSEActionCenterView: React.FC<HSEActionCenterViewProps> = ({
  onSelectReport,
  onNavigate,
}) => {
  const [reports, setReports] = useState<SafetyReport[]>([]);
  const [capas, setCapas] = useState<CAPARecord[]>([]);
  const [selectedReportForCapa, setSelectedReportForCapa] = useState<SafetyReport | null>(null);
  const [showCapaModal, setShowCapaModal] = useState(false);

  // Editable CAPA Form State
  const [capaTitle, setCapaTitle] = useState('');
  const [correctiveAction, setCorrectiveAction] = useState('');
  const [preventiveAction, setPreventiveAction] = useState('');
  const [responsibleRole, setResponsibleRole] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [priority, setPriority] = useState<CAPARecord['priority']>('Critical');
  const [verificationMethod, setVerificationMethod] = useState('');

  useEffect(() => {
    fetchActions();
    fetchCapas();
  }, []);

  const fetchActions = async () => {
    try {
      const res = await fetch('/api/reports');
      const data: SafetyReport[] = await res.json();
      // Filter for actionable reports
      setReports(data.filter((r) => r.risk_level === 'CRITICAL' || r.risk_level === 'HIGH'));
    } catch {
      // fallback
    }
  };

  const fetchCapas = async () => {
    try {
      const res = await fetch('/api/capas');
      const data = await res.json();
      setCapas(data);
    } catch {
      // fallback
    }
  };

  const handleOpenCapa = (report: SafetyReport) => {
    setSelectedReportForCapa(report);
    setCapaTitle(`CAPA for ${report.report_id}: ${report.iogp_primary} Compliance`);
    setCorrectiveAction(
      `Issue immediate Stop-Work Order on ${report.rig_id}; physically inspect and tag zero-energy barrier.`
    );
    setPreventiveAction(
      `Update site JSA, conduct Toolpusher barrier verification walkdown, and recalibrate detection arrays.`
    );
    setResponsibleRole('Lead Rig Safety Superintendent & Asset Toolpusher');
    setPriority(report.risk_level === 'CRITICAL' ? 'Critical' : 'High');

    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 5);
    setTargetDate(futureDate.toISOString().split('T')[0]);
    setVerificationMethod('Physical sign-off walkdown, zero pressure log, and calibrated instrument verification.');
    setShowCapaModal(true);
  };

  const handleSaveCapa = () => {
    const newCapa: CAPARecord = {
      id: `CAPA-2026-${Math.floor(100 + Math.random() * 900)}`,
      reportId: selectedReportForCapa?.report_id || 'OIL-UNKNOWN',
      title: capaTitle,
      correctiveAction,
      preventiveAction,
      responsibleRole,
      priority,
      targetDate,
      verificationMethod,
      status: 'Approved',
      aiGenerated: true,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setCapas([newCapa, ...capas]);
    setShowCapaModal(false);
    alert('CAPA successfully recorded and approved by authorized HSE role!');
  };

  const handleVerifyStopWork = async (reportId: string, action: 'approve' | 'decline') => {
    try {
      await fetch(`/api/reports/${reportId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      fetchActions();
      alert(`HSE action recorded: ${action === 'approve' ? 'Stop-Work Order Authorized!' : 'Downgraded'}`);
    } catch {
      alert('Verification update failed.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-rose-600" />
            <h1 className="text-xl font-bold text-slate-900">HSE Action Center & CAPA Workflow</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800 uppercase">
              Section 13-15
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Prioritized HSE queue enforcing conditional Human-in-the-Loop safety gates and automated CAPA generation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-600">Pending HSE Gates:</span>
          <span className="px-2.5 py-1 rounded-full text-xs font-black bg-rose-600 text-white font-mono">
            {reports.filter((r) => r.human_verification_status !== 'Approved').length} REQUIRE VERIFICATION
          </span>
        </div>
      </div>

      {/* Human-in-the-Loop Governance Notice (Section 15) */}
      <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border-2 border-amber-300 rounded-2xl p-5 shadow-sm space-y-2">
        <div className="flex items-center gap-2 text-xs font-extrabold uppercase text-amber-900 tracking-wider">
          <UserCheck className="h-4 w-4 text-amber-700" />
          <span>CONDITIONAL HUMAN-IN-THE-LOOP SAFETY GATE (SECTION 15 MANDATE)</span>
        </div>
        <p className="text-xs text-amber-950 leading-relaxed font-medium">
          Sentriq operates strictly as a <strong>decision-support intelligence layer</strong>. The system issues
          recommendations, highlights precursor triggers, and prepares CAPA drafts, but{' '}
          <strong>never independently actuates physical rig machinery or automatic shutdown valves</strong>. All
          Stop-Work recommendations await authorized human HSE sign-off.
        </p>
      </div>

      {/* Prioritized HSE Queue Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
            PRIORITIZED PRECURSOR ACTION QUEUE
          </h2>
          <span className="text-xs text-slate-500 font-mono">{reports.length} Priority Observations</span>
        </div>

        <div className="space-y-3">
          {reports.map((report) => {
            const isVerified = report.human_verification_status === 'Approved';
            return (
              <div
                key={report.report_id}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        report.risk_level === 'CRITICAL'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}
                    >
                      {report.risk_level}
                    </span>
                    <span className="font-mono text-xs font-bold text-cyan-700">{report.report_id}</span>
                    <span className="text-xs text-slate-500 font-medium">
                      {report.site} • {report.rig_id}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-blue-50 text-blue-700 font-semibold border border-blue-200">
                      Rule: {report.iogp_primary}
                    </span>
                  </div>

                  <p className="text-xs font-bold text-slate-900 leading-snug">
                    {report.raw_text}
                  </p>

                  <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-600">
                    <div>
                      <strong className="text-slate-800">Failed Barrier:</strong>{' '}
                      {report.failed_barriers.hardware?.[0] || report.failed_barriers.procedural?.[0]}
                    </div>
                    <div>
                      <strong className="text-slate-800">Governance State:</strong>{' '}
                      <span className={isVerified ? 'text-emerald-700 font-bold' : 'text-rose-700 font-bold'}>
                        {report.human_verification_status || 'Awaiting authorized HSE verification'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    onClick={() => onSelectReport(report)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 cursor-pointer"
                  >
                    Review Dossier
                  </button>

                  <button
                    onClick={() => handleOpenCapa(report)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-300 cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-cyan-600" />
                    <span>Generate CAPA</span>
                  </button>

                  {!isVerified ? (
                    <button
                      onClick={() => handleVerifyStopWork(report.report_id, 'approve')}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-sm cursor-pointer"
                    >
                      Authorize Stop-Work
                    </button>
                  ) : (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 px-2 py-1 bg-emerald-50 rounded-lg border border-emerald-200">
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Authorized</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active CAPA Log Table (Section 14) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">Active CAPA (Corrective & Preventive Actions) Log</h2>
          </div>
          <span className="text-xs font-mono text-slate-500">{capas.length} Registered CAPAs</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-2.5 px-4">CAPA ID</th>
                <th className="py-2.5 px-4">Observation Reference</th>
                <th className="py-2.5 px-4">Corrective Action</th>
                <th className="py-2.5 px-4">Preventive Action</th>
                <th className="py-2.5 px-4">Responsible Role</th>
                <th className="py-2.5 px-4">Priority</th>
                <th className="py-2.5 px-4">Target Date</th>
                <th className="py-2.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {capas.map((capa) => (
                <tr key={capa.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-700">{capa.id}</td>
                  <td className="py-3 px-4 font-mono text-slate-600">{capa.reportId}</td>
                  <td className="py-3 px-4 text-slate-800 font-medium max-w-xs">{capa.correctiveAction}</td>
                  <td className="py-3 px-4 text-slate-700 max-w-xs">{capa.preventiveAction}</td>
                  <td className="py-3 px-4 text-slate-700 font-semibold">{capa.responsibleRole}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded font-black text-[10px] ${
                        capa.priority === 'Critical'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {capa.priority}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">{capa.targetDate}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {capa.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CAPA Generator Modal (Section 14) */}
      {showCapaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-cyan-400" />
                <h3 className="text-base font-bold">Generate CAPA for {selectedReportForCapa?.report_id}</h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-900 text-cyan-300 font-bold">
                AI-ASSISTED CAPA DRAFT
              </span>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">CAPA Title</label>
                <input
                  type="text"
                  value={capaTitle}
                  onChange={(e) => setCapaTitle(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Immediate Corrective Action (Stop-Work / Isolation)
                </label>
                <textarea
                  rows={2}
                  value={correctiveAction}
                  onChange={(e) => setCorrectiveAction(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Systemic Preventive Action (Process & Engineering)
                </label>
                <textarea
                  rows={2}
                  value={preventiveAction}
                  onChange={(e) => setPreventiveAction(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Responsible Role</label>
                  <input
                    type="text"
                    value={responsibleRole}
                    onChange={(e) => setResponsibleRole(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 font-medium"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Closeout Date</label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Verification Method</label>
                <input
                  type="text"
                  value={verificationMethod}
                  onChange={(e) => setVerificationMethod(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 font-medium"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowCapaModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 border border-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCapa}
                className="px-5 py-2 rounded-lg text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/30 cursor-pointer"
              >
                Approve & Save CAPA
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
