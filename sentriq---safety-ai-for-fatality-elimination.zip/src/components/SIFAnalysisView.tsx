import React from 'react';
import {
  ShieldAlert,
  Flame,
  AlertTriangle,
  Compass,
  Users,
  Radio,
  FileCheck,
  CheckCircle2,
  Info,
  ArrowRight,
  ExternalLink,
  Layers,
  Cpu,
} from 'lucide-react';
import { SafetyReport } from '../types';

interface SIFAnalysisViewProps {
  report: SafetyReport;
  onNavigate: (tab: string) => void;
}

export const SIFAnalysisView: React.FC<SIFAnalysisViewProps> = ({
  report,
  onNavigate,
}) => {
  // Render highlighted text with SHAP-style explanation spans
  const renderHighlightedNarrative = () => {
    let narrative = report.raw_text;
    const highlights = report.explainability?.highlightedPhrases || [];

    if (!highlights.length) {
      return <span>{narrative}</span>;
    }

    // Sort highlights by length descending to prevent nesting collision
    const sorted = [...highlights].sort((a, b) => b.text.length - a.text.length);

    // Simple replacement token markers
    type Token = { text: string; category?: 'critical' | 'risk' | 'context'; reason?: string };
    const tokens: Token[] = [{ text: narrative }];

    sorted.forEach((hl) => {
      for (let i = 0; i < tokens.length; i++) {
        const t = tokens[i];
        if (t.category) continue; // already categorized

        const lowerText = t.text.toLowerCase();
        const lowerHl = hl.text.toLowerCase();
        const index = lowerText.indexOf(lowerHl);

        if (index !== -1) {
          const before = t.text.slice(0, index);
          const match = t.text.slice(index, index + hl.text.length);
          const after = t.text.slice(index + hl.text.length);

          const newSubTokens: Token[] = [];
          if (before) newSubTokens.push({ text: before });
          newSubTokens.push({ text: match, category: hl.category, reason: hl.reason });
          if (after) newSubTokens.push({ text: after });

          tokens.splice(i, 1, ...newSubTokens);
          break;
        }
      }
    });

    return (
      <div className="leading-relaxed text-sm">
        {tokens.map((tok, idx) => {
          if (tok.category === 'critical') {
            return (
              <span
                key={idx}
                title={`Critical Trigger: ${tok.reason || ''}`}
                className="bg-rose-100 text-rose-900 border border-rose-300 font-bold px-1.5 py-0.5 rounded mx-0.5"
              >
                {tok.text}
              </span>
            );
          }
          if (tok.category === 'risk') {
            return (
              <span
                key={idx}
                title={`Risk Factor: ${tok.reason || ''}`}
                className="bg-amber-100 text-amber-900 border border-amber-300 font-semibold px-1.5 py-0.5 rounded mx-0.5"
              >
                {tok.text}
              </span>
            );
          }
          if (tok.category === 'context') {
            return (
              <span
                key={idx}
                title={`Context: ${tok.reason || ''}`}
                className="bg-blue-100 text-blue-900 border border-blue-200 px-1 py-0.5 rounded mx-0.5"
              >
                {tok.text}
              </span>
            );
          }
          return <span key={idx}>{tok.text}</span>;
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: SIF Potential Classification (Section 6) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 overflow-hidden relative">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
              <span className="font-bold text-cyan-700">{report.report_id}</span>
              <span>•</span>
              <span>{report.site} ({report.rig_id})</span>
              <span>•</span>
              <span>{report.timestamp}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
              SIF Precursor Intelligence Dossier
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <span
              className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border ${
                report.risk_level === 'CRITICAL'
                  ? 'bg-rose-100 text-rose-800 border-rose-300'
                  : report.risk_level === 'HIGH'
                  ? 'bg-amber-100 text-amber-800 border-amber-300'
                  : 'bg-blue-100 text-blue-800 border-blue-300'
              }`}
            >
              RISK: {report.risk_level}
            </span>

            <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300 font-mono">
              {report.confidence_label}: {report.sif_confidence}%
            </span>
          </div>
        </div>

        {/* Primary Classification Callout */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-4 bg-gradient-to-br from-rose-50 to-red-50 border-2 border-rose-300 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-700 block">
                SIF Potential Determination
              </span>
              <div className="text-3xl font-black text-rose-800 mt-1 flex items-center gap-2">
                <ShieldAlert className="h-8 w-8 text-rose-600" />
                <span>{report.sif_potential === 'YES' ? 'POTENTIAL: YES' : 'POTENTIAL: NO'}</span>
              </div>
            </div>
            <div className="mt-3 text-xs text-rose-950 font-medium">
              Potential exposure to high-energy / hazardous condition with failed safety controls.
            </div>
          </div>

          <div className="md:col-span-8 bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Potential Catastrophic Consequence (Uncontained Top Event)
              </span>
              <div className="text-sm font-bold text-slate-900 mt-1 leading-snug">
                {report.potential_consequence}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-slate-700">
                Decision Support Gate:
                <span className="ml-1 text-rose-700 font-bold">
                  {report.human_verification_status || 'Awaiting authorized HSE verification'}
                </span>
              </span>
              <button
                onClick={() => onNavigate('actions')}
                className="text-cyan-700 hover:text-cyan-900 font-bold underline cursor-pointer"
              >
                HSE Stop-Work Verification →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Explainable AI (XAI) Panel (Section 7) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900">WHY SENTRIQ FLAGGED THIS REPORT</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-bold border border-purple-200">
                {report.explainability?.method || 'SHAP-style Feature Attribution - DEMO'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Attention tokens showing which phrases triggered high-energy SIF classification
            </p>
          </div>

          {/* Color Legend */}
          <div className="flex items-center gap-3 text-xs bg-slate-50 p-1.5 rounded-lg border border-slate-200 font-medium">
            <div className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-rose-500"></span>
              <span className="text-slate-700">Critical trigger</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-amber-500"></span>
              <span className="text-slate-700">Hazard context</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-blue-500"></span>
              <span className="text-slate-700">Operational context</span>
            </div>
          </div>
        </div>

        {/* Highlighted Original Text Box */}
        <div className="p-4 bg-slate-50/80 rounded-xl border border-slate-200 text-slate-800 shadow-inner">
          <div className="text-[10px] font-mono font-bold text-slate-400 mb-1">
            ORIGINAL OBSERVATION TEXT WITH NLP PHRASE ATTRIBUTION:
          </div>
          {renderHighlightedNarrative()}
        </div>

        {/* Explainability Triggers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {report.explainability?.triggers?.map((trig, idx) => (
            <div key={idx} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-700">
              <span className="h-1.5 w-1.5 rounded-full bg-rose-500 inline-block mr-1.5" />
              <span>{trig}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Triad of Failed Barriers & IOGP Life-Saving Rules (Section 6) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: IOGP Rules (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">IOGP Life-Saving Rules</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
              Standardized Mappings
            </span>
          </div>

          <div className="space-y-3">
            {/* Primary Rule Card */}
            <div className="p-4 rounded-xl border-2 border-blue-400 bg-blue-50/60">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-700 block">
                Primary Life-Saving Rule Triggered
              </span>
              <div className="text-lg font-black text-blue-950 mt-1 flex items-center gap-2">
                <Compass className="h-5 w-5 text-blue-700" />
                <span>{report.iogp_primary}</span>
              </div>
              <p className="text-xs text-blue-900 mt-1.5 font-medium">
                Verify isolation and zero energy state before starting any work. Test before touch.
              </p>
            </div>

            {/* Secondary Rule Card */}
            {report.iogp_secondary && (
              <div className="p-3.5 rounded-xl border border-amber-300 bg-amber-50/60">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-700 block">
                  Secondary Associated Rule
                </span>
                <div className="text-base font-bold text-amber-950 mt-0.5">{report.iogp_secondary}</div>
                <p className="text-xs text-amber-900 mt-1">
                  Obtain authorized permit and never bypass, silence, or disable critical safety safeguards.
                </p>
              </div>
            )}
          </div>

          {/* Hazard Entities Extracted */}
          <div className="pt-2 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Hazard Extraction (NER Entities)
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">Energy Source</span>
                <span className="font-bold text-slate-800 mt-0.5 block">{report.energy_source}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">Equipment</span>
                <span className="font-bold text-slate-800 mt-0.5 block">{report.equipment}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">Activity</span>
                <span className="font-bold text-slate-800 mt-0.5 block">{report.activity}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">Location</span>
                <span className="font-bold text-slate-800 mt-0.5 block">{report.location}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Failed Barriers Breakdown (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">Failed Barrier Classification</h2>
            <span className="text-xs text-slate-500">Root-cause defense degradation</span>
          </div>

          <div className="space-y-3">
            {/* Hardware / Engineered Barrier */}
            <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/50 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-rose-600" />
                  Hardware / Engineered Barrier Failure
                </span>
                <span className="text-[10px] font-bold text-rose-700 uppercase bg-rose-200/70 px-2 py-0.5 rounded">
                  DEFECTIVE / OFFLINE
                </span>
              </div>
              <ul className="list-disc pl-4 text-xs text-slate-800 space-y-1 font-medium">
                {report.failed_barriers.hardware?.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>

            {/* Procedural Barrier */}
            <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/50 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-800 flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-amber-600" />
                  Procedural / Permit Barrier Failure
                </span>
                <span className="text-[10px] font-bold text-amber-700 uppercase bg-amber-200/70 px-2 py-0.5 rounded">
                  BYPASSED / UNVERIFIED
                </span>
              </div>
              <ul className="list-disc pl-4 text-xs text-slate-800 space-y-1 font-medium">
                {report.failed_barriers.procedural?.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>

            {/* Human / Administrative Barrier */}
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-800 flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-blue-600" />
                  Human / Administrative Factor Failure
                </span>
                <span className="text-[10px] font-bold text-blue-700 uppercase bg-blue-200/70 px-2 py-0.5 rounded">
                  SWA NON-COMPLIANCE
                </span>
              </div>
              <ul className="list-disc pl-4 text-xs text-slate-800 space-y-1 font-medium">
                {report.failed_barriers.human?.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Quick Module Jump Links */}
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              onClick={() => onNavigate('bowtie')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow"
            >
              <Compass className="h-3.5 w-3.5 text-cyan-400" />
              <span>Simulate Bowtie Diagram →</span>
            </button>
            <button
              onClick={() => onNavigate('cards')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold cursor-pointer border border-slate-300"
            >
              <Users className="h-3.5 w-3.5 text-slate-600" />
              <span>Worker Safety Card</span>
            </button>
            <button
              onClick={() => onNavigate('fleet')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold cursor-pointer border border-indigo-200"
            >
              <Radio className="h-3.5 w-3.5 text-indigo-600" />
              <span>Fleet Immunity Search</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
