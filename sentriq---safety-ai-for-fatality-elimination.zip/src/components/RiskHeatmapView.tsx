import React, { useState, useEffect } from 'react';
import {
  Flame,
  Filter,
  MapPin,
  ShieldAlert,
  AlertTriangle,
  Compass,
  Layers,
  ChevronRight,
  Info,
  X,
} from 'lucide-react';

interface AssetHeatmapData {
  site: string;
  zone: string;
  rigs: string[];
  sifDensity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  activeHazards: string[];
  sifRatio: number;
  totalObservations: number;
  activeAlerts: number;
}

interface RiskHeatmapViewProps {
  onNavigate: (tab: string) => void;
}

export const RiskHeatmapView: React.FC<RiskHeatmapViewProps> = ({ onNavigate }) => {
  const [heatmapData, setHeatmapData] = useState<AssetHeatmapData[]>([]);
  const [selectedAsset, setSelectedAsset] = useState<AssetHeatmapData | null>(null);

  // Filters
  const [selectedSite, setSelectedSite] = useState<string>('all');
  const [selectedRisk, setSelectedRisk] = useState<string>('all');
  const [selectedRule, setSelectedRule] = useState<string>('all');

  useEffect(() => {
    fetchHeatmap();
  }, []);

  const fetchHeatmap = async () => {
    try {
      const res = await fetch('/api/heatmap');
      const data = await res.json();
      setHeatmapData(data);
      if (data.length > 0) {
        setSelectedAsset(data[0]);
      }
    } catch {
      // fallback
    }
  };

  const filteredAssets = heatmapData.filter((item) => {
    if (selectedSite !== 'all' && item.site !== selectedSite) return false;
    if (selectedRisk !== 'all' && item.sifDensity !== selectedRisk) return false;
    return true;
  });

  const getDensityColor = (density: string) => {
    switch (density) {
      case 'CRITICAL':
        return 'from-rose-600 to-red-700 text-white border-rose-500';
      case 'HIGH':
        return 'from-amber-500 to-orange-600 text-white border-amber-400';
      case 'MEDIUM':
        return 'from-blue-500 to-indigo-600 text-white border-blue-400';
      default:
        return 'from-emerald-500 to-teal-600 text-white border-emerald-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Flame className="h-6 w-6 text-rose-600" />
            <h1 className="text-xl font-bold text-slate-900">Enterprise Asset Risk Heatmap</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800 uppercase font-mono">
              SIF Precursor Density
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Spatial monitoring of precursor density across Oil India operational assets in Upper Assam and Rajasthan basins.
          </p>
        </div>

        {/* Filters Bar (Section 12) */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            <Filter className="h-3.5 w-3.5 text-slate-500" />
            <select
              value={selectedSite}
              onChange={(e) => setSelectedSite(e.target.value)}
              className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer"
            >
              <option value="all">All Sites / Assets</option>
              <option value="Duliajan Field">Duliajan Field</option>
              <option value="Digboi Field">Digboi Field</option>
              <option value="Moran Field">Moran Field</option>
              <option value="Rajasthan Asset">Rajasthan Asset</option>
              <option value="Jorhat / Sibsagar">Jorhat / Sibsagar</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-slate-500 font-semibold">Density:</span>
            <select
              value={selectedRisk}
              onChange={(e) => setSelectedRisk(e.target.value)}
              className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer"
            >
              <option value="all">All Densities</option>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Heatmap Grid & Detail Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Field Tiles (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredAssets.map((asset, idx) => {
              const isSelected = selectedAsset?.site === asset.site;
              return (
                <div
                  key={idx}
                  onClick={() => setSelectedAsset(asset)}
                  className={`p-5 rounded-2xl border-2 transition-all cursor-pointer relative overflow-hidden bg-white shadow-sm hover:shadow-md ${
                    isSelected ? 'border-cyan-600 ring-4 ring-cyan-600/10' : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h2 className="text-base font-extrabold text-slate-900 leading-tight">{asset.site}</h2>
                      <span className="text-xs text-slate-500 font-medium">{asset.zone}</span>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r ${getDensityColor(
                        asset.sifDensity
                      )}`}
                    >
                      {asset.sifDensity}
                    </span>
                  </div>

                  {/* SIF Ratio Visual Progress */}
                  <div className="space-y-1 mb-3">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-600">SIF Precursor Ratio</span>
                      <span className="font-mono font-bold text-slate-900">{asset.sifRatio}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full ${
                          asset.sifRatio > 45 ? 'bg-rose-600' : asset.sifRatio > 30 ? 'bg-amber-500' : 'bg-blue-600'
                        }`}
                        style={{ width: `${asset.sifRatio}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100">
                    <span>{asset.rigs.length} Active Rigs</span>
                    <span className="font-mono">{asset.totalObservations} Observations</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[11px] text-slate-400 text-center font-mono">
            * All spatial hazard metrics are synthetic demonstrations for SIH 2026.
          </div>
        </div>

        {/* Right: Selected Asset Deep Dive Card (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          {selectedAsset ? (
            <>
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    ASSET SIF PROFILE
                  </span>
                  <h2 className="text-lg font-bold text-slate-900">{selectedAsset.site}</h2>
                  <span className="text-xs text-slate-500">{selectedAsset.zone}</span>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-black text-white bg-gradient-to-r ${getDensityColor(
                    selectedAsset.sifDensity
                  )}`}
                >
                  {selectedAsset.sifDensity} DENSITY
                </span>
              </div>

              {/* Monitored Rigs & Units */}
              <div>
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Monitored Rigs & Surface Installations:
                </span>
                <div className="flex flex-wrap gap-2">
                  {selectedAsset.rigs.map((rig, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 text-xs font-bold border border-slate-200"
                    >
                      {rig}
                    </span>
                  ))}
                </div>
              </div>

              {/* Active Precursor Hazards */}
              <div>
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Top Active Precursor Patterns:
                </span>
                <div className="space-y-2">
                  {selectedAsset.activeHazards.map((haz, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800"
                    >
                      <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
                      <span>{haz}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="pt-3 border-t border-slate-200 space-y-2">
                <button
                  onClick={() => onNavigate('fleet')}
                  className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200 cursor-pointer transition-colors"
                >
                  Run Fleet Immunity Cross-Check for {selectedAsset.site} →
                </button>
                <button
                  onClick={() => onNavigate('database')}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl border border-slate-300 cursor-pointer transition-colors"
                >
                  View All Logged Reports from {selectedAsset.site}
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-12 text-slate-400 text-xs">
              Select an asset on the left to inspect detailed SIF density.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
