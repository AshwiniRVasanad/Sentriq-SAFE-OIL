import React, { useState, useEffect } from 'react';
import {
  Radio,
  ShieldAlert,
  AlertTriangle,
  Send,
  CheckCircle2,
  Database,
  Search,
  ExternalLink,
  Layers,
  MapPin,
  Sparkles,
  Info,
} from 'lucide-react';
import { SafetyReport, FleetOperation } from '../types';

interface FleetImmunityViewProps {
  currentReport: SafetyReport;
  onNavigate: (tab: string) => void;
}

export const FleetImmunityView: React.FC<FleetImmunityViewProps> = ({
  currentReport,
  onNavigate,
}) => {
  const [similarRigs, setSimilarRigs] = useState<FleetOperation[]>([]);
  const [loading, setLoading] = useState(true);
  const [alertBroadcast, setAlertBroadcast] = useState(false);
  const [broadcastDetails, setBroadcastDetails] = useState<any>(null);

  useEffect(() => {
    fetchSimilarOperations();
  }, [currentReport]);

  const fetchSimilarOperations = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/fleet/similar?report_id=${currentReport.report_id}`);
      const data = await res.json();
      setSimilarRigs(data);
      setLoading(false);
    } catch {
      setLoading(false);
    }
  };

  const handleBroadcastAlert = async () => {
    try {
      const res = await fetch('/api/fleet/alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          precursor: `${currentReport.iogp_primary}: ${currentReport.energy_source}`,
          sites: similarRigs.map((r) => r.site),
          recommendedAction:
            'Conduct immediate verification of isolation and safety device status across all active high-risk operations.',
          severity: currentReport.risk_level,
        }),
      });
      const data = await res.json();
      setBroadcastDetails(data);
      setAlertBroadcast(true);
    } catch {
      alert('Alert transmission failed.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="h-6 w-6 text-indigo-600 animate-pulse" />
            <h1 className="text-xl font-bold text-slate-900">Cross-Rig Fleet Immunity Swarm</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 uppercase">
              Simulated Enterprise Network
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            When a high-risk precursor is identified at one asset, Sentriq proactively searches the synthetic enterprise dataset for similar active operations.
          </p>
        </div>

        <button
          onClick={handleBroadcastAlert}
          disabled={alertBroadcast}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer ${
            alertBroadcast
              ? 'bg-emerald-600 text-white cursor-default'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 active:scale-95'
          }`}
        >
          {alertBroadcast ? <CheckCircle2 className="h-4 w-4" /> : <Send className="h-4 w-4" />}
          <span>{alertBroadcast ? 'Swarm Alert Broadcasted' : 'Broadcast Fleet Precursor Warning'}</span>
        </button>
      </div>

      {/* Broadcast Banner Confirmation */}
      {alertBroadcast && broadcastDetails && (
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-4 rounded-xl shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-6 w-6 text-white shrink-0" />
            <div className="text-xs">
              <strong className="block text-sm font-bold">
                FLEET IMMUNITY TRANSMISSION CONFIRMED ({broadcastDetails.alertId})
              </strong>
              Transmitted to Toolpushers & HSE officers across {broadcastDetails.notifiedSites?.join(', ')}.
            </div>
          </div>
          <span className="text-[11px] font-mono font-bold bg-white/20 px-2.5 py-1 rounded">
            STATUS: ACTIVE SWARM ADVISORY
          </span>
        </div>
      )}

      {/* Source Incident Dossier Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-6 rounded-2xl border border-slate-700 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-700 pb-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping"></span>
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
              TRIGGERING SOURCE PRECURSOR EVENT
            </span>
          </div>
          <span className="text-xs font-mono text-slate-400">{currentReport.report_id}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Source Asset</span>
            <span className="font-bold text-white text-sm mt-0.5 block">{currentReport.site}</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Rig ID</span>
            <span className="font-bold text-white text-sm mt-0.5 block">{currentReport.rig_id}</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Active Activity</span>
            <span className="font-bold text-white text-sm mt-0.5 block">{currentReport.activity}</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase">Equipment</span>
            <span className="font-bold text-white text-sm mt-0.5 block">{currentReport.equipment}</span>
          </div>
        </div>

        <p className="text-xs text-slate-300 italic bg-slate-950/40 p-3 rounded-lg border border-slate-800/80">
          &ldquo;{currentReport.raw_text}&rdquo;
        </p>
      </div>

      {/* Similar Active Operations Detected Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
              SIMILAR ACTIVE OPERATIONS DETECTED IN FLEET
            </h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
              SIMILARITY MATCH ENGINE
            </span>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {similarRigs.length} Sister Assets Matching Precursor Envelope
          </span>
        </div>

        {loading ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
            <p className="text-xs text-slate-500 mt-2">Searching synthetic rig fleet vectors...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {similarRigs.map((rig, idx) => (
              <div
                key={idx}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-slate-900 text-base">{rig.rigId}</span>
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-indigo-100 text-indigo-800 font-mono">
                      {rig.similarityScore}% SIMILARITY
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-3">
                    <MapPin className="h-3.5 w-3.5 text-slate-400" />
                    <span>{rig.site}</span>
                    <span>•</span>
                    <span className="font-semibold text-slate-700">{rig.status}</span>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Operation:</span>
                      <strong className="text-slate-800">{rig.activity}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Equipment:</span>
                      <strong className="text-slate-800">{rig.equipment}</strong>
                    </div>
                    <div className="pt-1 border-t border-slate-200/70 text-[11px] text-indigo-900 font-semibold">
                      Precursor: {rig.precursorMatch}
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-slate-100 text-xs">
                  <span
                    className={`font-bold text-[10px] px-2 py-0.5 rounded ${
                      rig.riskScore === 'CRITICAL'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    EXPOSURE: {rig.riskScore}
                  </span>

                  <button
                    onClick={() => {
                      alert(`Advisory briefing generated for ${rig.rigId} (${rig.site})! Toolpusher alerted.`);
                    }}
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline cursor-pointer"
                  >
                    Generate Rig Briefing →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* PostgreSQL + pgvector Production Architecture Note (Section 2 & 11) */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-5 rounded-2xl border border-indigo-800/60 shadow-md">
        <div className="flex items-start gap-3">
          <Database className="h-6 w-6 text-indigo-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs">
            <div className="font-bold text-indigo-200 text-sm">
              Vector Embedding Architecture Roadmap (PostgreSQL + pgvector)
            </div>
            <p className="text-slate-300 leading-relaxed">
              In this prototype demonstration, cross-rig similarity is computed using metadata heuristics and NLP term attribution via <code className="text-cyan-300 font-mono">findSimilarOperations()</code>. The codebase is architected with a repository abstraction layer designed for drop-in migration to PostgreSQL with pgvector embeddings (e.g., using <code className="text-cyan-300 font-mono">gemini-embedding-2-preview</code> or BERT) across enterprise telemetry.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
