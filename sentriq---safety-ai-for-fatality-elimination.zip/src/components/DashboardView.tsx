import React from 'react';
import {
  ShieldAlert,
  Flame,
  AlertTriangle,
  Radio,
  FileCheck,
  TrendingUp,
  Layers,
  ArrowRight,
  Sparkles,
  ChevronRight,
  Info,
  Calendar,
  Compass,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  Legend,
  PieChart,
  Pie,
} from 'recharts';
import { DashboardSummary, SafetyReport } from '../types';

interface DashboardViewProps {
  summary: DashboardSummary | null;
  onSelectReport: (report: SafetyReport) => void;
  onNavigate: (tab: string) => void;
  onRunSignatureDemo: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summary,
  onSelectReport,
  onNavigate,
  onRunSignatureDemo,
}) => {
  if (!summary) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-600"></div>
      </div>
    );
  }

  const kpis = [
    {
      label: 'Total Reports Ingested',
      value: summary.totalReports.toLocaleString(),
      sub: 'All synthetic field logs',
      icon: Layers,
      color: 'from-blue-600 to-indigo-700',
      textColor: 'text-blue-600',
      demoTag: 'DEMO DATA',
    },
    {
      label: 'SIF Potential Identified',
      value: summary.sifPotentialCount.toLocaleString(),
      sub: '23% of total observations',
      icon: ShieldAlert,
      color: 'from-rose-600 to-red-700',
      textColor: 'text-rose-600',
      demoTag: 'DEMO DATA',
    },
    {
      label: 'High/Critical Risk Level',
      value: summary.highRiskCount.toLocaleString(),
      sub: 'Immediate action queue',
      icon: Flame,
      color: 'from-amber-500 to-orange-600',
      textColor: 'text-amber-600',
      demoTag: 'DEMO DATA',
    },
    {
      label: 'Critical Barriers Failed',
      value: summary.criticalBarriersCount.toLocaleString(),
      sub: 'Hardware & procedural',
      icon: AlertTriangle,
      color: 'from-purple-600 to-pink-700',
      textColor: 'text-purple-600',
      demoTag: 'DEMO DATA',
    },
    {
      label: 'IOGP Rules Triggered',
      value: `${summary.iogpRulesTriggeredCount} / 9`,
      sub: 'Industry safety baseline',
      icon: Compass,
      color: 'from-emerald-600 to-teal-700',
      textColor: 'text-emerald-600',
      demoTag: 'DEMO DATA',
    },
    {
      label: 'Active Fleet Alerts',
      value: summary.activeFleetAlertsCount.toLocaleString(),
      sub: 'Cross-rig swarm alerts',
      icon: Radio,
      color: 'from-cyan-600 to-blue-700',
      textColor: 'text-cyan-600',
      demoTag: 'DEMO DATA',
    },
  ];

  const BARRIER_COLORS = ['#ef4444', '#f59e0b', '#3b82f6'];

  return (
    <div className="space-y-6">
      {/* Hero Banner for SIH Judges */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-700/60 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-cyan-500/10 to-transparent pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-xs font-semibold border border-cyan-500/30">
              SIH 2026 • PS 26165 • Oil India Limited
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-medium">
              Explainable AI SIF Intelligence
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            SENTRIQ: Safety AI for Fatality Elimination
          </h1>
          <p className="mt-2 text-slate-300 text-sm sm:text-base leading-relaxed">
            Transforming unstructured, qualitative frontline safety reports into explainable, proactive SIF risk intelligence.
            Moving beyond reactive lagging metrics to predictive barrier defense.
          </p>

          {/* Visual Architecture Flow Banner (Prompt requirement #24) */}
          <div className="mt-5 p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] font-semibold text-slate-300">
            <div className="flex items-center gap-1.5 text-cyan-400">
              <span className="h-5 w-5 rounded bg-cyan-900/60 flex items-center justify-center font-bold">1</span>
              <span>RAW REPORT</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-blue-400">
              <span className="h-5 w-5 rounded bg-blue-900/60 flex items-center justify-center font-bold">2</span>
              <span>AI / NLP MAPPING</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-rose-400">
              <span className="h-5 w-5 rounded bg-rose-900/60 flex items-center justify-center font-bold">3</span>
              <span>SIF PRECURSOR</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-amber-400">
              <span className="h-5 w-5 rounded bg-amber-900/60 flex items-center justify-center font-bold">4</span>
              <span>FAILED BARRIER</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-purple-400">
              <span className="h-5 w-5 rounded bg-purple-900/60 flex items-center justify-center font-bold">5</span>
              <span>BOWTIE: WHAT COULD HAPPEN?</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="h-5 w-5 rounded bg-emerald-900/60 flex items-center justify-center font-bold">6</span>
              <span>WORKER ACTION</span>
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-slate-600 hidden sm:block" />
            <div className="flex items-center gap-1.5 text-cyan-300">
              <span className="h-5 w-5 rounded bg-cyan-950 flex items-center justify-center font-bold">7</span>
              <span>FLEET IMMUNITY</span>
            </div>
          </div>

          {/* Quick CTA buttons */}
          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={onRunSignatureDemo}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-lg text-xs sm:text-sm font-bold shadow-lg shadow-cyan-500/25 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              <Sparkles className="h-4 w-4" />
              <span>Launch Signature Demo Scenario</span>
            </button>
            <button
              onClick={() => onNavigate('ingest')}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs sm:text-sm font-semibold border border-slate-700 flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Submit Live Report</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div
              key={idx}
              className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
                  {kpi.demoTag}
                </span>
                <div className={`p-1.5 rounded-lg bg-gradient-to-br ${kpi.color} text-white shadow-sm`}>
                  <Icon className="h-3.5 w-3.5" />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{kpi.value}</div>
              <div className="text-xs font-semibold text-slate-700 mt-0.5 line-clamp-1">{kpi.label}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">{kpi.sub}</div>
            </div>
          );
        })}
      </div>

      {/* AI Insight Panel (Prompt requirement #4) */}
      <div className="bg-gradient-to-r from-blue-50 via-cyan-50 to-indigo-50 border border-cyan-200 rounded-xl p-5 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-cyan-600 text-white shadow-md shadow-cyan-600/30">
            <Sparkles className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-cyan-950 uppercase tracking-wide">
                SENTRIQ AI WEEKLY PATTERN MINING
              </h2>
              <span className="text-[10px] font-bold text-cyan-800 bg-cyan-200/80 px-2 py-0.5 rounded">
                AUTONOMOUS CLUSTER DETECTION
              </span>
            </div>
            <div className="text-base font-extrabold text-slate-900 mt-1">
              {summary.aiWeeklyInsights.title}
            </div>
            <ul className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-700 font-medium">
              {summary.aiWeeklyInsights.patterns.map((pat, idx) => (
                <li key={idx} className="flex items-start gap-2 bg-white/80 p-2.5 rounded-lg border border-cyan-100">
                  <span className="h-2 w-2 rounded-full bg-rose-500 mt-1 shrink-0" />
                  <span>{pat}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 text-xs text-cyan-900 bg-white/60 p-2.5 rounded-lg border border-cyan-200 flex items-center justify-between">
              <span>
                <strong>HSE Recommendation:</strong> {summary.aiWeeklyInsights.recommendation}
              </span>
              <button
                onClick={() => onNavigate('fleet')}
                className="text-cyan-700 hover:text-cyan-900 font-bold ml-2 underline shrink-0 cursor-pointer"
              >
                Inspect Fleet Alerts →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Charts Row: Trend + Rig Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Trend Area Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">SIF Precursor Trend Over Time</h2>
              <p className="text-xs text-slate-500">7-Day Rolling Window (Synthetic Enterprise Log)</p>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
              DEMO DATA
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={summary.sifTrend}>
                <defs>
                  <linearGradient id="sifColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="nonSifColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area
                  type="monotone"
                  dataKey="sifCount"
                  name="SIF Potential Reports"
                  stroke="#ef4444"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#sifColor)"
                />
                <Area
                  type="monotone"
                  dataKey="nonSifCount"
                  name="Routine / Low Risk"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#nonSifColor)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Rig / Asset SIF Ratio Bar Chart (5 cols) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">SIF Precursor Density by Rig</h2>
              <p className="text-xs text-slate-500">Percentage of observations with SIF potential</p>
            </div>
            <button
              onClick={() => onNavigate('heatmap')}
              className="text-xs font-semibold text-cyan-600 hover:text-cyan-800 cursor-pointer"
            >
              Heatmap →
            </button>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={summary.rigDistribution} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" domain={[0, 100]} unit="%" stroke="#94a3b8" fontSize={10} />
                <YAxis dataKey="rig" type="category" stroke="#64748b" fontSize={11} width={80} tickLine={false} />
                <Tooltip
                  formatter={(val: any) => [`${val}% SIF Ratio`, 'SIF Density']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="sifRatio" radius={[0, 4, 4, 0]}>
                  {summary.rigDistribution.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.sifRatio > 40 ? '#ef4444' : entry.sifRatio > 25 ? '#f59e0b' : '#3b82f6'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Secondary Charts Row: IOGP Rules + Failed Barriers + Hazard Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* IOGP Life-Saving Rules */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h2 className="text-sm font-bold text-slate-900 mb-1">IOGP Life-Saving Rules Triggered</h2>
          <p className="text-xs text-slate-500 mb-3">Precursor frequency across industry rules</p>
          <div className="space-y-2.5">
            {summary.iogpDistribution.slice(0, 5).map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span>{item.rule}</span>
                  <span className="font-mono text-slate-500">{item.count} reports ({item.percentage}%)</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${Math.min(item.percentage * 2, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Failed Barrier Breakdown */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Failed Barrier Classification</h2>
          <p className="text-xs text-slate-500 mb-3">Hardware vs Procedural vs Human Factors</p>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={summary.barrierDistribution}
                  dataKey="count"
                  nameKey="barrierType"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                >
                  {summary.barrierDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={BARRIER_COLORS[index % BARRIER_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '11px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-1 text-[11px] text-center pt-2 border-t border-slate-100 font-semibold">
            <div className="text-red-600">Hardware ({summary.barrierDistribution[0]?.count || 0})</div>
            <div className="text-amber-600">Procedural ({summary.barrierDistribution[1]?.count || 0})</div>
            <div className="text-blue-600">Human ({summary.barrierDistribution[2]?.count || 0})</div>
          </div>
        </div>

        {/* Hazard Category Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Energy Source / Hazard Categories</h2>
          <p className="text-xs text-slate-500 mb-3">Stored high-energy triggers</p>
          <div className="space-y-2">
            {summary.hazardDistribution.map((haz, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-medium text-slate-800 truncate pr-2">{haz.category}</span>
                <span className="px-2 py-0.5 rounded bg-slate-200 font-bold text-slate-700 font-mono text-[11px]">
                  {haz.count}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Critical Reports Table (Prompt requirement #4) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-rose-600" />
              <span>Recent High-Priority SIF Precursor Observations</span>
            </h2>
            <p className="text-xs text-slate-500">Live stream requiring authorized HSE review</p>
          </div>
          <button
            onClick={() => onNavigate('database')}
            className="text-xs font-semibold text-cyan-600 hover:text-cyan-800 flex items-center gap-1 cursor-pointer"
          >
            <span>View All Reports ({summary.totalReports.toLocaleString()})</span>
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <th className="py-2.5 px-4">Report ID</th>
                <th className="py-2.5 px-4">Site / Asset</th>
                <th className="py-2.5 px-4">Rig</th>
                <th className="py-2.5 px-4">Observation Narrative</th>
                <th className="py-2.5 px-4">Primary IOGP Rule</th>
                <th className="py-2.5 px-4">Risk Level</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {summary.recentCriticalReports.map((report) => (
                <tr key={report.report_id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-700">{report.report_id}</td>
                  <td className="py-3 px-4 font-medium text-slate-800">{report.site}</td>
                  <td className="py-3 px-4 text-slate-600 font-semibold">{report.rig_id}</td>
                  <td className="py-3 px-4 text-slate-700 max-w-xs truncate" title={report.raw_text}>
                    {report.raw_text}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded font-medium text-[11px] bg-blue-50 text-blue-700 border border-blue-200">
                      {report.iogp_primary}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        report.risk_level === 'CRITICAL'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}
                    >
                      {report.risk_level}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => onSelectReport(report)}
                      className="px-2.5 py-1 bg-cyan-50 hover:bg-cyan-100 text-cyan-700 font-semibold rounded text-xs border border-cyan-200 cursor-pointer transition-colors"
                    >
                      Deep SIF Analysis →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
