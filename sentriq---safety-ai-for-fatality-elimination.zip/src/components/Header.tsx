import React from 'react';
import {
  ShieldAlert,
  Flame,
  Activity,
  Compass,
  FileText,
  AlertTriangle,
  PlayCircle,
  HelpCircle,
  Radio,
  FileSpreadsheet,
  Settings,
  Server,
  Users,
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRunLiveDemo: () => void;
  isGeminiConnected: boolean;
  totalAlertsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onRunLiveDemo,
  isGeminiConnected,
  totalAlertsCount = 12,
}) => {
  const navItems = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'ingest', label: 'Live Ingestion', icon: FileSpreadsheet },
    { id: 'analysis', label: 'SIF Analysis', icon: ShieldAlert },
    { id: 'bowtie', label: 'Bowtie Simulator', icon: Compass },
    { id: 'cards', label: 'Worker Safety Cards', icon: Users },
    { id: 'fleet', label: 'Fleet Immunity', icon: Radio, badge: 'Swarm' },
    { id: 'heatmap', label: 'Risk Heatmap', icon: Flame },
    { id: 'actions', label: 'HSE Actions', icon: AlertTriangle, count: 4 },
    { id: 'database', label: 'Reports Data', icon: FileText },
    { id: 'settings', label: 'Architecture', icon: Settings },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-md">
      {/* Top Banner & Status */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Product Title */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <ShieldAlert className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white">SENTRIQ</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  SIH 2026 • PS 26165
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/80 flex items-center gap-1 font-mono">
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                  DEMO ENVIRONMENT
                </span>
              </div>
              <div className="text-xs text-slate-400 hidden sm:block">
                Safety AI for Fatality Elimination • Oil India Limited Prototype
              </div>
            </div>
          </div>

          {/* Right Controls: AI Engine Status + Live Demo Button */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700 text-xs">
              <Server className="h-3.5 w-3.5 text-cyan-400" />
              <span className="text-slate-400">Engine:</span>
              <span className={isGeminiConnected ? 'text-emerald-400 font-medium' : 'text-cyan-300 font-medium'}>
                {isGeminiConnected ? 'Gemini 3.8 Flash' : 'Deterministic NLP (Demo)'}
              </span>
            </div>

            <button
              onClick={onRunLiveDemo}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-md shadow-cyan-600/30 transition-all cursor-pointer border border-cyan-400/40 active:scale-95"
            >
              <PlayCircle className="h-4 w-4" />
              <span>Run Live Demo</span>
            </button>
          </div>
        </div>

        {/* Navigation Bar */}
        <nav className="flex space-x-1 overflow-x-auto py-2 border-t border-slate-800/80 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-cyan-600/20 text-cyan-400 border border-cyan-500/40'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-1 text-[10px] font-bold px-1.5 py-0.2 rounded bg-cyan-900 text-cyan-200">
                    {item.badge}
                  </span>
                )}
                {item.count && (
                  <span className="ml-1 text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-rose-900 text-rose-200">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Synthetic Data Disclaimer Ribbon */}
      <div className="bg-slate-950/90 border-t border-slate-800/50 py-1 px-4 text-center text-[11px] text-slate-400 flex items-center justify-center gap-2">
        <HelpCircle className="h-3 w-3 text-cyan-400 inline" />
        <span>
          <strong>Notice:</strong> Prototype demonstration using synthetic safety records. Not connected to live OIL operational equipment or SCADA control systems.
        </span>
      </div>
    </header>
  );
};
