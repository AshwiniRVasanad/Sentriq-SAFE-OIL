import React, { useState } from 'react';
import {
  Compass,
  AlertTriangle,
  Flame,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  RefreshCw,
  HelpCircle,
  CheckCircle2,
  XCircle,
  Check,
} from 'lucide-react';
import { SafetyReport, BowtieBarrier } from '../types';

interface BowtieSimulatorViewProps {
  report: SafetyReport;
  onNavigate: (tab: string) => void;
}

export const BowtieSimulatorView: React.FC<BowtieSimulatorViewProps> = ({
  report,
  onNavigate,
}) => {
  const [showWhatCouldHappen, setShowWhatCouldHappen] = useState(true);
  const [preventiveBarriers, setPreventiveBarriers] = useState<BowtieBarrier[]>(
    report.bowtie?.preventiveBarriers || []
  );
  const [mitigatingBarriers, setMitigatingBarriers] = useState<BowtieBarrier[]>(
    report.bowtie?.mitigatingBarriers || []
  );

  // Toggle barrier status for interactive "What-If" barrier restoration simulation
  const togglePreventive = (index: number) => {
    setPreventiveBarriers((prev) => {
      const copy = [...prev];
      const cur = copy[index].status;
      copy[index].status = cur === 'failed' ? 'effective' : cur === 'degraded' ? 'effective' : 'failed';
      return copy;
    });
  };

  const toggleMitigating = (index: number) => {
    setMitigatingBarriers((prev) => {
      const copy = [...prev];
      const cur = copy[index].status;
      copy[index].status = cur === 'failed' ? 'effective' : cur === 'degraded' ? 'effective' : 'failed';
      return copy;
    });
  };

  const allPreventiveEffective = preventiveBarriers.every((b) => b.status === 'effective');
  const allMitigatingEffective = mitigatingBarriers.every((b) => b.status === 'effective');
  const chainBroken = allPreventiveEffective || (preventiveBarriers.filter((b) => b.status === 'effective').length >= 2);

  const threats = report.bowtie?.threats || [
    'Accumulation of fugitive hydrocarbon vapors near hot work zone',
    'Residual pressurized oil/gas trapped behind unverified valve',
  ];

  const consequences = report.bowtie?.potentialConsequences || [
    'Flash fire and hydrocarbon vapor cloud explosion (VCE)',
    'Multiple personnel fatalities within 25-meter radius',
    'Catastrophic structural damage to rig installation',
  ];

  return (
    <div className="space-y-6">
      {/* Top Header & Simulation Controls */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="h-6 w-6 text-cyan-600" />
            <h1 className="text-xl font-bold text-slate-900">Bowtie Precursor Risk Simulator</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-100 text-cyan-800 uppercase">
              Section 8 Decision Support
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Visualizing threat escalation, compromised defense barriers, top events, and mitigation controls for{' '}
            <strong className="text-slate-800">{report.report_id}</strong> ({report.site} • {report.rig_id}).
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs bg-slate-50 p-2 rounded-xl border border-slate-200 font-semibold">
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded bg-emerald-500"></span>
            <span className="text-slate-700">Effective Barrier</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded bg-amber-500"></span>
            <span className="text-slate-700">Degraded Barrier</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded bg-rose-500"></span>
            <span className="text-slate-700">Failed / Bypassed</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Bowtie Canvas */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-700 relative overflow-hidden">
        {/* Dynamic Chain Status Banner */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
          <div className="flex items-center gap-2">
            {chainBroken ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-rose-500 animate-pulse" />
            )}
            <span className="text-xs font-bold text-slate-200">
              {chainBroken ? (
                <span className="text-emerald-300">
                  CHAIN INTERRUPTED: Sufficient preventive barriers restored to arrest top event.
                </span>
              ) : (
                <span className="text-rose-300">
                  UNBROKEN RISK ESCALATION: Multiple critical barrier defenses are degraded or failed.
                </span>
              )}
            </span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Interactive: Click any barrier card to toggle between Failed & Effective status
          </span>
        </div>

        {/* 5-Column Bowtie Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-center">
          {/* Column 1: Threats (Left) */}
          <div className="space-y-3">
            <div className="text-xs font-extrabold uppercase tracking-wider text-cyan-400 text-center pb-1 border-b border-cyan-500/30">
              1. INITIATING THREATS
            </div>
            {threats.map((t, idx) => (
              <div
                key={idx}
                className="bg-slate-800/90 border border-slate-700 p-3 rounded-xl text-xs text-slate-200 font-medium shadow-sm hover:border-cyan-500 transition-colors"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 inline-block mr-1.5" />
                <span>{t}</span>
              </div>
            ))}
          </div>

          {/* Column 2: Preventive Barriers */}
          <div className="space-y-2.5">
            <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-400 text-center pb-1 border-b border-emerald-500/30">
              2. PREVENTIVE BARRIERS
            </div>
            {preventiveBarriers.map((b, idx) => {
              const isFailed = b.status === 'failed';
              const isDegraded = b.status === 'degraded';
              return (
                <button
                  key={idx}
                  onClick={() => togglePreventive(idx)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer relative ${
                    isFailed
                      ? 'bg-rose-950/70 border-rose-500/80 text-rose-100 hover:bg-rose-900/60'
                      : isDegraded
                      ? 'bg-amber-950/70 border-amber-500/80 text-amber-100 hover:bg-amber-900/60'
                      : 'bg-emerald-950/70 border-emerald-500/80 text-emerald-100 hover:bg-emerald-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase mb-1">
                    <span className="text-slate-300">{b.type}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded font-black text-[9px] ${
                        isFailed ? 'bg-rose-500 text-white' : isDegraded ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white'
                      }`}
                    >
                      {b.status}
                    </span>
                  </div>
                  <div className="text-xs font-semibold leading-tight">{b.name}</div>
                </button>
              );
            })}
          </div>

          {/* Column 3: TOP EVENT (Center Core) */}
          <div className="text-center px-2 py-4">
            <div className="h-32 w-32 sm:h-36 sm:w-36 rounded-full mx-auto flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-rose-600 to-red-800 shadow-2xl shadow-rose-600/40 border-4 border-rose-400 relative">
              <div className="absolute -top-3 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono font-bold text-rose-300 uppercase">
                TOP EVENT
              </div>
              <Flame className="h-6 w-6 text-white mb-1 animate-bounce" />
              <div className="text-xs font-black text-white leading-tight uppercase">
                {report.bowtie?.topEvent || 'Loss of Containment & Uncontrolled Ignition'}
              </div>
            </div>
            <div className="mt-3 text-[11px] text-slate-400 font-mono">
              Uncontrolled energy breach point
            </div>
          </div>

          {/* Column 4: Mitigating Barriers */}
          <div className="space-y-2.5">
            <div className="text-xs font-extrabold uppercase tracking-wider text-blue-400 text-center pb-1 border-b border-blue-500/30">
              3. MITIGATING BARRIERS
            </div>
            {mitigatingBarriers.map((b, idx) => {
              const isFailed = b.status === 'failed';
              const isDegraded = b.status === 'degraded';
              return (
                <button
                  key={idx}
                  onClick={() => toggleMitigating(idx)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer relative ${
                    isFailed
                      ? 'bg-rose-950/70 border-rose-500/80 text-rose-100 hover:bg-rose-900/60'
                      : isDegraded
                      ? 'bg-amber-950/70 border-amber-500/80 text-amber-100 hover:bg-amber-900/60'
                      : 'bg-emerald-950/70 border-emerald-500/80 text-emerald-100 hover:bg-emerald-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase mb-1">
                    <span className="text-slate-300">{b.type}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded font-black text-[9px] ${
                        isFailed ? 'bg-rose-500 text-white' : isDegraded ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white'
                      }`}
                    >
                      {b.status}
                    </span>
                  </div>
                  <div className="text-xs font-semibold leading-tight">{b.name}</div>
                </button>
              );
            })}
          </div>

          {/* Column 5: Consequences (Right) */}
          <div className="space-y-3">
            <div className="text-xs font-extrabold uppercase tracking-wider text-rose-400 text-center pb-1 border-b border-rose-500/30">
              4. CATASTROPHIC CONSEQUENCES
            </div>
            {consequences.map((c, idx) => (
              <div
                key={idx}
                className="bg-rose-950/30 border border-rose-500/40 p-3 rounded-xl text-xs text-rose-200 font-medium shadow-sm"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-rose-500 inline-block mr-1.5" />
                <span>{c}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Explanatory Cards: "What Could Happen?" & "How to Break the Chain" (Section 8) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* What Could Happen Card */}
        <div className="bg-gradient-to-br from-rose-50 to-orange-50 rounded-2xl border-2 border-rose-200 p-6 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="h-5 w-5 text-rose-600" />
              <h2 className="text-base font-black text-rose-950 uppercase tracking-wide">
                WHAT COULD HAPPEN?
              </h2>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-200 text-rose-800">
              SCENARIO SYNTHESIS
            </span>
          </div>

          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium bg-white/70 p-3.5 rounded-xl border border-rose-200">
            {report.bowtie?.whatCouldHappen ||
              'IF hot work sparks ignite residual gas while LOTO is unverified AND the gas detector remains offline, THEN an immediate explosion will occur without prior audible alarm, resulting in fatal burns and structural collapse.'}
          </p>

          <div className="text-[11px] text-rose-900 font-medium flex items-center gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5 text-rose-600 shrink-0" />
            <span>SIF pre-cursor: Concurrent failure of primary physical isolation and secondary monitoring.</span>
          </div>
        </div>

        {/* How to Break the Chain Card */}
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border-2 border-emerald-200 p-6 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-emerald-600" />
              <h2 className="text-base font-black text-emerald-950 uppercase tracking-wide">
                HOW TO BREAK THE CHAIN
              </h2>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200 text-emerald-800">
              PREVENTIVE INTERVENTIONS
            </span>
          </div>

          <ul className="space-y-2 text-xs text-slate-800 font-medium">
            {(
              report.bowtie?.howToBreakTheChain || [
                'IMMEDIATELY exercise Stop-Work Authority (SWA) and suspend hot work.',
                'Physically verify zero energy via double-block-and-bleed gauge checks.',
                'Restore or calibrate Zone 3 gas detector; provide continuous calibrated 4-gas clip monitors.',
                'Re-issue PTW (Permit to Work) with joint Toolpusher and HSE signature verification.',
              ]
            ).map((action, idx) => (
              <li key={idx} className="flex items-start gap-2 bg-white/80 p-2.5 rounded-lg border border-emerald-100">
                <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{action}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Human Governance Footer Disclaimer */}
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <HelpCircle className="h-4 w-4 text-cyan-600" />
          <span>
            <strong>Decision-Support Notice:</strong> Bowtie simulations are algorithmic analytical models for HSE risk visualization. The AI system possesses no physical control actuators over rig valves, mud pumps, or electrical breakers.
          </span>
        </div>
        <button
          onClick={() => onNavigate('cards')}
          className="text-xs font-bold text-cyan-700 hover:text-cyan-900 underline shrink-0 ml-4 cursor-pointer"
        >
          Generate Worker Safety Card →
        </button>
      </div>
    </div>
  );
};
