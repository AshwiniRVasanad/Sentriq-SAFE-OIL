import React, { useState, useEffect } from 'react';
import {
  FileText,
  Upload,
  Mic,
  MicOff,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Play,
  FileSpreadsheet,
  Globe,
  Radio,
  Volume2,
} from 'lucide-react';
import { SafetyReport, ReportType, ReporterType } from '../types';

interface ReportIngestionViewProps {
  onReportAnalyzed: (report: SafetyReport) => void;
  onNavigateToAnalysis: () => void;
}

export const ReportIngestionView: React.FC<ReportIngestionViewProps> = ({
  onReportAnalyzed,
  onNavigateToAnalysis,
}) => {
  const [activeTab, setActiveTab] = useState<'text' | 'voice' | 'csv'>('text');

  // Form Fields
  const [site, setSite] = useState('Duliajan Field');
  const [rigId, setRigId] = useState('Rig OIL-14');
  const [location, setLocation] = useState('Zone 3 / Process Manifold Deck');
  const [activity, setActivity] = useState('Hot Work / Line Repair');
  const [reportType, setReportType] = useState<ReportType>('Near Miss');
  const [reporterType, setReporterType] = useState<ReporterType>('Frontline Worker');
  const [rawText, setRawText] = useState(
    'During hot work in Zone 3, the gas detector was offline and the crew started work before LOTO verification. Supervisor was informed but work continued.'
  );

  // Voice State
  const [voiceLang, setVoiceLang] = useState<'en' | 'hi' | 'as'>('hi');
  const [isRecording, setIsRecording] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [isTranscribing, setIsTranscribing] = useState(false);

  // Processing Animation State
  const [isProcessing, setIsProcessing] = useState(false);
  const [pipelineStep, setPipelineStep] = useState(0);

  const pipelineSteps = [
    'INGESTING OBSERVATION',
    'NORMALIZING TERMINOLOGY',
    'SIF PRECURSOR DETECTION',
    'IOGP LIFE-SAVING RULES MAPPING',
    'FAILED BARRIER IDENTIFICATION',
    'EXPLAINABLE AI ATTRIBUTION',
    'ACTION RECOMMENDATION GENERATION',
  ];

  // Signature demo presets
  const demoScenarios = [
    {
      title: 'Signature SIF: Gas Detector Offline & LOTO Bypass',
      text: 'During hot work in Zone 3, the gas detector was offline and the crew started work before LOTO verification. Supervisor was informed but work continued.',
      site: 'Duliajan Field',
      rigId: 'Rig OIL-14',
      activity: 'Hot Work / Line Repair',
      reportType: 'Near Miss' as ReportType,
    },
    {
      title: 'Derrick High Fall: Unhooked Harness on Monkey Board',
      text: 'Derrickman observed on monkey board at 90 ft unhooking safety harness lanyard while moving between fingerboard racks during heavy rain gust.',
      site: 'Digboi Field',
      rigId: 'Rig OIL-21',
      activity: 'Working at Height / Tripping Pipe',
      reportType: 'Unsafe Act' as ReportType,
    },
    {
      title: 'High Pressure Iron: Mud Pump Missing Whip-Checks',
      text: 'High pressure pulsation dampener on Mud Pump 2 experienced rapid pressure oscillation reaching 4200 PSI. Pop-off relief valve line showed loose anchor clamps and missing safety whip-checks.',
      site: 'Moran Field',
      rigId: 'Rig OIL-07',
      activity: 'Drilling / Circulating Mud',
      reportType: 'Near Miss' as ReportType,
    },
    {
      title: 'Confined Space & H2S Alarm: Active Mud Tank Entry',
      text: 'Contractor personnel entered active mud tank compartment without confined space permit, without breathing apparatus, and with zero ventilation running. H2S sensor alarm went off at 15 PPM inside cellar.',
      site: 'Rajasthan Asset',
      rigId: 'Rig OIL-03',
      activity: 'Confined Space Cleaning',
      reportType: 'Incident' as ReportType,
    },
  ];

  const handleLoadScenario = (sc: (typeof demoScenarios)[0]) => {
    setRawText(sc.text);
    setSite(sc.site);
    setRigId(sc.rigId);
    setActivity(sc.activity);
    setReportType(sc.reportType);
  };

  const handleClear = () => {
    setRawText('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rawText.trim()) return;

    setIsProcessing(true);
    setPipelineStep(0);

    // Simulate progressive pipeline steps in UI
    const stepInterval = setInterval(() => {
      setPipelineStep((prev) => {
        if (prev < pipelineSteps.length - 1) {
          return prev + 1;
        }
        clearInterval(stepInterval);
        return prev;
      });
    }, 350);

    try {
      const response = await fetch('/api/reports/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          raw_text: rawText,
          site,
          rig_id: rigId,
          location,
          activity,
          report_type: reportType,
          reporter_type: reporterType,
        }),
      });

      const analyzedReport = await response.json();

      setTimeout(() => {
        clearInterval(stepInterval);
        setIsProcessing(false);
        onReportAnalyzed(analyzedReport);
        onNavigateToAnalysis();
      }, 2600);
    } catch {
      clearInterval(stepInterval);
      setIsProcessing(false);
      alert('Analysis failed. Please check network connection.');
    }
  };

  // Voice recording simulation / browser API
  const handleToggleVoice = async () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    setIsRecording(true);
    setVoiceTranscript('');

    // Pre-canned simulated worker utterances per language
    const sampleUtterances = {
      hi: 'बीओपी लाइन में लीकेज हो रहा है, तुरंत काम रोकना चाहिए। वाल्व पर प्रेशर बढ़ रहा है।',
      as: 'বিঅ’পি পাইপলাইনত লিক ওলাইছে, কাম তৎক্ষণাত বন্ধ কৰিব লাগে। গেছৰ গোন্ধ পাইছো।',
      en: 'Gas detector is alarming in Zone 3 near the manifold. Hot work must be halted immediately.',
    };

    setTimeout(async () => {
      const sample = sampleUtterances[voiceLang];
      setVoiceTranscript(sample);
      setIsRecording(false);
      setIsTranscribing(true);

      try {
        const res = await fetch('/api/voice/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ transcript: sample, language: voiceLang }),
        });
        const data = await res.json();
        setRawText(data.normalized);
        if (data.suggestedActivity) setActivity(data.suggestedActivity);
        if (data.suggestedLocation) setLocation(data.suggestedLocation);
        setIsTranscribing(false);
        setActiveTab('text');
      } catch {
        setIsTranscribing(false);
      }
    }, 2200);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">Ingest Safety Observation</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-100 text-cyan-800 uppercase">
              NLP Ingestion Gateway
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Submit free-text observations, field voice memos in Hindi/Assamese/English, or bulk CSV audit logs.
          </p>
        </div>

        {/* Ingestion Mode Selector Tabs */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('text')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'text' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="h-3.5 w-3.5 text-cyan-600" />
            <span>Free-Text Form</span>
          </button>
          <button
            onClick={() => setActiveTab('voice')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'voice' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Mic className="h-3.5 w-3.5 text-rose-600" />
            <span>Frontline Voice Input</span>
          </button>
          <button
            onClick={() => setActiveTab('csv')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'csv' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Upload className="h-3.5 w-3.5 text-blue-600" />
            <span>CSV Batch Ingestion</span>
          </button>
        </div>
      </div>

      {/* Voice Mode View */}
      {activeTab === 'voice' && (
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-6 rounded-2xl border border-slate-700 shadow-lg space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                Frontline Audio Prototype (Section 10)
              </span>
              <h2 className="text-lg font-bold text-white mt-0.5">Worker Voice Report Transcription</h2>
              <p className="text-xs text-slate-400">
                Dictate in English, Hindi, or Assamese. Sentriq transcribes and normalizes colloquial field jargon into structured HSE data.
              </p>
            </div>

            {/* Language Selector */}
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg border border-slate-700 text-xs">
              <Globe className="h-3.5 w-3.5 text-cyan-400 ml-1" />
              <button
                onClick={() => setVoiceLang('en')}
                className={`px-2 py-1 rounded cursor-pointer ${
                  voiceLang === 'en' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-300'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setVoiceLang('hi')}
                className={`px-2 py-1 rounded cursor-pointer ${
                  voiceLang === 'hi' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-300'
                }`}
              >
                हिन्दी (Hindi)
              </button>
              <button
                onClick={() => setVoiceLang('as')}
                className={`px-2 py-1 rounded cursor-pointer ${
                  voiceLang === 'as' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-300'
                }`}
              >
                অসমীয়া (Assamese)
              </button>
            </div>
          </div>

          {/* Voice Record Interaction Area */}
          <div className="p-8 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col items-center justify-center text-center space-y-4">
            <button
              onClick={handleToggleVoice}
              className={`h-20 w-20 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-xl ${
                isRecording
                  ? 'bg-rose-600 animate-pulse text-white ring-8 ring-rose-600/30'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white hover:scale-105 shadow-cyan-600/30'
              }`}
            >
              {isRecording ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
            </button>

            <div>
              <div className="font-bold text-sm text-white">
                {isRecording
                  ? 'Listening to frontline speech...'
                  : isTranscribing
                  ? 'Normalizing dialect & extracting HSE entities...'
                  : 'Click microphone to simulate worker voice input'}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {voiceLang === 'hi' && 'Simulates: "बीओपी लाइन में लीकेज हो रहा है, तुरंत काम रोकना चाहिए..."'}
                {voiceLang === 'as' && 'Simulates: "বিঅ’পি পাইপলাইনত লিক ওলাইছে, কাম তৎক্ষণাত বন্ধ কৰিব লাগে..."'}
                {voiceLang === 'en' && 'Simulates: "Gas detector is alarming in Zone 3 near the manifold..."'}
              </div>
            </div>

            {voiceTranscript && (
              <div className="w-full max-w-lg p-3 rounded-lg bg-slate-900 border border-slate-700 text-left font-mono text-xs text-emerald-400">
                <span className="text-[10px] text-slate-500 block font-sans">RAW SPEECH CAPTURED:</span>
                &ldquo;{voiceTranscript}&rdquo;
              </div>
            )}
          </div>
        </div>
      )}

      {/* CSV Batch Upload Tab */}
      {activeTab === 'csv' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Batch CSV Safety Observations</h2>
              <p className="text-xs text-slate-500">
                Upload historical rig incident and near-miss spreadsheets for bulk SIF precursor classification.
              </p>
            </div>
            <a
              href="#csv-sample"
              onClick={(e) => {
                e.preventDefault();
                alert('Sample template headers: report_id, timestamp, site, rig_id, location, activity, report_type, raw_text, reporter_type');
              }}
              className="text-xs font-semibold text-cyan-600 hover:text-cyan-800"
            >
              Download Sample CSV Schema
            </a>
          </div>

          <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-cyan-500 transition-colors bg-slate-50">
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <div className="text-sm font-bold text-slate-800">Drag & drop CSV file or click to browse</div>
            <p className="text-xs text-slate-500 mt-1">Accepts standard .csv files with up to 500 rows per batch</p>
            <button
              onClick={() => {
                alert('Synthetic batch upload simulated: 14 reports processed into database.');
                setActiveTab('text');
              }}
              className="mt-4 px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs cursor-pointer shadow"
            >
              Simulate Ingesting Batch (14 Records)
            </button>
          </div>
        </div>
      )}

      {/* Main Free-Text Input Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        {/* Quick Demo Preload Buttons */}
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
            Preload Signature Demo Scenarios:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {demoScenarios.map((sc, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleLoadScenario(sc)}
                className="text-left p-2.5 rounded-lg border border-slate-200 hover:border-cyan-500 hover:bg-cyan-50/50 transition-all text-xs cursor-pointer group"
              >
                <div className="font-bold text-slate-800 group-hover:text-cyan-700 line-clamp-1">{sc.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{sc.rigId} • {sc.activity}</div>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Site / Asset</label>
              <select
                value={site}
                onChange={(e) => setSite(e.target.value)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Duliajan Field">Duliajan Field (Upper Assam)</option>
                <option value="Digboi Field">Digboi Field (Heritage Field)</option>
                <option value="Moran Field">Moran Field (High Structural)</option>
                <option value="Rajasthan Asset">Rajasthan Asset (Jaisalmer)</option>
                <option value="Jorhat / Sibsagar Field">Jorhat / Sibsagar Field</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Rig / Unit ID</label>
              <input
                type="text"
                value={rigId}
                onChange={(e) => setRigId(e.target.value)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 font-medium focus:ring-2 focus:ring-cyan-500"
                placeholder="e.g. Rig OIL-14"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Location / Zone</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 font-medium focus:ring-2 focus:ring-cyan-500"
                placeholder="e.g. Zone 3 Manifold Deck"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Activity</label>
              <input
                type="text"
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 font-medium focus:ring-2 focus:ring-cyan-500"
                placeholder="e.g. Hot Work / Line Repair"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Report Type</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value as ReportType)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Near Miss">Near Miss</option>
                <option value="Unsafe Act">Unsafe Act</option>
                <option value="Unsafe Condition">Unsafe Condition</option>
                <option value="Incident">Incident</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Reporter Type</label>
              <select
                value={reporterType}
                onChange={(e) => setReporterType(e.target.value as ReporterType)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Frontline Worker">Frontline Worker</option>
                <option value="Roustabout">Roustabout / Roughneck</option>
                <option value="Driller">Driller / Toolpusher</option>
                <option value="HSE Officer">HSE Officer</option>
                <option value="Maintenance Tech">Maintenance Technician</option>
                <option value="Subcontractor">Subcontractor Labor</option>
              </select>
            </div>
          </div>

          {/* Main Unstructured Text Field */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Describe What Happened (Unstructured Observation Narrative)
              </label>
              <span className="text-[11px] text-slate-400">Supports free-form text</span>
            </div>
            <textarea
              rows={4}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full p-3.5 rounded-xl border border-slate-300 text-sm font-sans focus:ring-2 focus:ring-cyan-500 leading-relaxed text-slate-900 bg-slate-50/50"
              placeholder="During maintenance near the high-pressure line, the crew started work before LOTO verification. The gas detector in Zone 3 was offline."
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={handleClear}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Clear</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleLoadScenario(demoScenarios[0])}
                className="px-3.5 py-2 text-xs font-semibold text-cyan-700 bg-cyan-50 hover:bg-cyan-100 rounded-lg border border-cyan-200 cursor-pointer"
              >
                Load Signature Scenario
              </button>

              <button
                type="submit"
                disabled={isProcessing || !rawText.trim()}
                className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-sm rounded-lg shadow-md shadow-cyan-600/30 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
              >
                <Sparkles className="h-4 w-4" />
                <span>ANALYZE REPORT</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Processing Pipeline Modal Overlay (Section 5 requirement) */}
      {isProcessing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 text-white rounded-2xl p-6 max-w-md w-full border border-slate-700 shadow-2xl text-center space-y-5">
            <div className="h-14 w-14 rounded-full bg-cyan-600/20 border border-cyan-400/40 flex items-center justify-center mx-auto text-cyan-400 animate-spin">
              <Sparkles className="h-7 w-7" />
            </div>

            <div>
              <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                Sentriq Multi-Stage AI Pipeline
              </div>
              <h3 className="text-lg font-bold text-white mt-1">Analyzing Field Observation</h3>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                Model: Gemini 3.8 / Hybrid NLP Feature Engine
              </p>
            </div>

            {/* Pipeline Stage Steps Indicator */}
            <div className="space-y-1.5 text-left text-xs bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
              {pipelineSteps.map((st, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-2 py-1 px-2 rounded font-mono text-[11px] ${
                    i === pipelineStep
                      ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                      : i < pipelineStep
                      ? 'text-emerald-400'
                      : 'text-slate-600'
                  }`}
                >
                  {i < pipelineStep ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  ) : i === pipelineStep ? (
                    <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping"></span>
                  ) : (
                    <span className="h-2 w-2 rounded-full bg-slate-700"></span>
                  )}
                  <span>{st}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
