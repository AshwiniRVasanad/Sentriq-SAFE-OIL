import { SafetyReport, DashboardSummary, FleetOperation, CAPARecord } from '../types';
import { SEED_REPORTS } from './seedReports';
import { ADDITIONAL_REPORTS } from './additionalReports';

// Combine datasets to form a rich 60+ reports repository
class ReportsRepository {
  private reports: SafetyReport[] = [];
  private capas: CAPARecord[] = [];

  constructor() {
    this.reports = [...SEED_REPORTS, ...ADDITIONAL_REPORTS];
    this.initDemoCapas();
  }

  private initDemoCapas() {
    this.capas = [
      {
        id: 'CAPA-2026-001',
        reportId: 'OIL-DUL-2026-0842',
        title: 'Emergency LOTO Audit & Gas Detection Calibration on Zone-3 Manifold',
        correctiveAction: 'Immediate stop-work exercised; physically isolated and tagged Zone-3 manifold line with double-block-and-bleed verification.',
        preventiveAction: 'Institute mandatory joint Toolpusher/HSE pre-hot work gas meter sign-off and replace faulty stationary LEL detector.',
        responsibleRole: 'Field HSE Superintendent & Lead Mechanical Supervisor',
        priority: 'Critical',
        targetDate: '2026-10-02',
        verificationMethod: 'Third-party calibration certificate + physical lockbox inspection walkdown.',
        status: 'Approved',
        aiGenerated: true,
        createdAt: '2026-09-28',
      },
      {
        id: 'CAPA-2026-002',
        reportId: 'OIL-DIG-2026-0412',
        title: 'Rig Floor 100% Tie-off Interlock & Adverse Weather Wind Limit Enforcement',
        correctiveAction: 'Suspended monkey board tripping during squall; inspected derrickman harness and inertia reel.',
        preventiveAction: 'Install automated twin-lanyard hook sensors and calibrate anemometer wind alarm to 25 knots.',
        responsibleRole: 'Toolpusher & Rig Safety Officer',
        priority: 'Critical',
        targetDate: '2026-09-30',
        verificationMethod: 'Derrick climbing authorization audit + logbook signoff.',
        status: 'In Progress',
        aiGenerated: true,
        createdAt: '2026-09-27',
      },
      {
        id: 'CAPA-2026-003',
        reportId: 'OIL-MOR-2026-0188',
        title: 'High Pressure Mud Pump Whip-Check Installation Campaign',
        correctiveAction: 'Depressurized Mud Pump 2; installed rated whip-check cables across all PRV connections.',
        preventiveAction: 'Fleet-wide survey of all chiksan unions and high-pressure pulsation dampener restraints.',
        responsibleRole: 'Asset Maintenance Lead',
        priority: 'High',
        targetDate: '2026-10-05',
        verificationMethod: 'Physical verification stamp on all high pressure iron.',
        status: 'Approved',
        aiGenerated: true,
        createdAt: '2026-09-27',
      },
    ];
  }

  public getAll(): SafetyReport[] {
    return [...this.reports];
  }

  public getById(id: string): SafetyReport | undefined {
    return this.reports.find((r) => r.report_id === id);
  }

  public addReport(report: SafetyReport): SafetyReport {
    // Add to top of list
    this.reports.unshift(report);
    return report;
  }

  public updateStatus(id: string, status: SafetyReport['status'], verificationStatus?: SafetyReport['human_verification_status']): SafetyReport | undefined {
    const report = this.getById(id);
    if (report) {
      report.status = status;
      if (verificationStatus) {
        report.human_verification_status = verificationStatus;
      }
    }
    return report;
  }

  public getCapas(): CAPARecord[] {
    return [...this.capas];
  }

  public addCapa(capa: CAPARecord): CAPARecord {
    this.capas.unshift(capa);
    return capa;
  }

  public updateCapa(id: string, updates: Partial<CAPARecord>): CAPARecord | undefined {
    const capa = this.capas.find((c) => c.id === id);
    if (capa) {
      Object.assign(capa, updates);
    }
    return capa;
  }

  public getDashboardSummary(): DashboardSummary {
    const totalReports = this.reports.length;
    const sifPotentialCount = this.reports.filter((r) => r.sif_potential === 'YES').length;
    const highRiskCount = this.reports.filter((r) => r.risk_level === 'CRITICAL' || r.risk_level === 'HIGH').length;

    let criticalBarriersCount = 0;
    this.reports.forEach((r) => {
      criticalBarriersCount +=
        (r.failed_barriers.hardware?.length || 0) +
        (r.failed_barriers.procedural?.length || 0) +
        (r.failed_barriers.human?.length || 0);
    });

    // Count unique IOGP rules triggered
    const iogpSet = new Set<string>();
    const iogpCountMap: Record<string, number> = {};
    this.reports.forEach((r) => {
      if (r.iogp_primary) {
        iogpSet.add(r.iogp_primary);
        iogpCountMap[r.iogp_primary] = (iogpCountMap[r.iogp_primary] || 0) + 1;
      }
      if (r.iogp_secondary) {
        iogpSet.add(r.iogp_secondary);
        iogpCountMap[r.iogp_secondary] = (iogpCountMap[r.iogp_secondary] || 0) + 1;
      }
    });

    const iogpDistribution = Object.entries(iogpCountMap)
      .map(([rule, count]) => ({
        rule,
        count,
        percentage: Math.round((count / (totalReports || 1)) * 100),
      }))
      .sort((a, b) => b.count - a.count);

    // Rig distribution
    const rigMap: Record<string, { rig: string; site: string; count: number; sifCount: number }> = {};
    this.reports.forEach((r) => {
      const key = `${r.rig_id}-${r.site}`;
      if (!rigMap[key]) {
        rigMap[key] = { rig: r.rig_id, site: r.site, count: 0, sifCount: 0 };
      }
      rigMap[key].count++;
      if (r.sif_potential === 'YES') {
        rigMap[key].sifCount++;
      }
    });

    const rigDistribution = Object.values(rigMap).map((item) => ({
      rig: item.rig,
      site: item.site,
      count: item.count,
      sifRatio: Math.round((item.sifCount / item.count) * 100),
    }));

    // Failed Barrier Distribution
    let hardwareFails = 0;
    let proceduralFails = 0;
    let humanFails = 0;
    this.reports.forEach((r) => {
      hardwareFails += r.failed_barriers.hardware?.length || 0;
      proceduralFails += r.failed_barriers.procedural?.length || 0;
      humanFails += r.failed_barriers.human?.length || 0;
    });

    const barrierDistribution = [
      { barrierType: 'Hardware / Engineered Control', count: hardwareFails },
      { barrierType: 'Procedural / Permit Rule', count: proceduralFails },
      { barrierType: 'Human / Administrative Action', count: humanFails },
    ];

    // Hazard Distribution
    const hazardMap: Record<string, number> = {};
    this.reports.forEach((r) => {
      const cat = r.energy_source || 'Other Energy';
      const key = cat.split('/')[0].trim().slice(0, 24);
      hazardMap[key] = (hazardMap[key] || 0) + 1;
    });

    const hazardDistribution = Object.entries(hazardMap).map(([category, count]) => ({
      category,
      count,
    })).sort((a, b) => b.count - a.count).slice(0, 6);

    // Trend over time (simulated 7-day buckets)
    const sifTrend = [
      { date: 'Sep 22', sifCount: 4, nonSifCount: 12 },
      { date: 'Sep 23', sifCount: 6, nonSifCount: 15 },
      { date: 'Sep 24', sifCount: 5, nonSifCount: 14 },
      { date: 'Sep 25', sifCount: 8, nonSifCount: 18 },
      { date: 'Sep 26', sifCount: 7, nonSifCount: 13 },
      { date: 'Sep 27', sifCount: 9, nonSifCount: 16 },
      { date: 'Sep 28', sifCount: 11, nonSifCount: 14 },
    ];

    const recentCriticalReports = this.reports
      .filter((r) => r.risk_level === 'CRITICAL')
      .slice(0, 5);

    return {
      totalReports: 1248, // synthetic enterprise scale label
      sifPotentialCount: 286,
      highRiskCount: 74,
      criticalBarriersCount: 119,
      iogpRulesTriggeredCount: iogpSet.size || 8,
      activeFleetAlertsCount: 12,
      aiWeeklyInsights: {
        title: '3 Recurring SIF Precursor Patterns Detected This Week',
        patterns: [
          'Energy isolation bypass prior to hot work or flange work (4 rigs affected)',
          'High-pressure discharge line restraints & whip-check omissions (Duliajan & Moran)',
          'Gas detection / atmospheric monitor sensor maintenance faults in Zone 3',
        ],
        recommendation:
          'Issue fleet-wide stop-work recommendation for unverified LOTO; trigger Swarm Immunity verification audit across all drilling & workover assets.',
      },
      sifTrend,
      rigDistribution,
      iogpDistribution,
      barrierDistribution,
      hazardDistribution,
      recentCriticalReports,
    };
  }

  public findSimilarOperations(currentReport: Partial<SafetyReport>): FleetOperation[] {
    const text = ((currentReport.raw_text || '') + ' ' + (currentReport.activity || '') + ' ' + (currentReport.equipment || '')).toLowerCase();

    // Candidate rigs across synthetic enterprise
    const candidates: Array<{ site: string; rigId: string; activity: string; equipment: string; status: 'Active' | 'Standby' | 'Tripping' | 'Workover'; riskScore: 'CRITICAL' | 'HIGH' | 'MEDIUM'; lastReportDate: string }> = [
      { site: 'Moran Field', rigId: 'Rig OIL-07', activity: 'Hot Work / Manifold Maintenance', equipment: 'Production Header Piping', status: 'Active', riskScore: 'CRITICAL', lastReportDate: '2026-09-28' },
      { site: 'Digboi Field', rigId: 'Rig OIL-21', activity: 'Drilling & Mud Circulation', equipment: 'Mud Pump 1 & High Pressure Iron', status: 'Tripping', riskScore: 'HIGH', lastReportDate: '2026-09-27' },
      { site: 'Rajasthan Asset', rigId: 'Rig OIL-03', activity: 'Workover / Wellhead Servicing', equipment: 'Zone-3 Wellhead Tree & ESD', status: 'Active', riskScore: 'HIGH', lastReportDate: '2026-09-27' },
      { site: 'Duliajan Field', rigId: 'Rig OIL-14', activity: 'Drilling / Casing Running', equipment: 'BOP & Accumulator Manifold', status: 'Active', riskScore: 'CRITICAL', lastReportDate: '2026-09-28' },
      { site: 'Jorhat / Sibsagar Field', rigId: 'Rig OIL-09', activity: 'Tripping Out of Hole', equipment: 'Drawworks & Rotary Table', status: 'Workover', riskScore: 'MEDIUM', lastReportDate: '2026-09-26' },
    ];

    return candidates.map((cand) => {
      let score = 70;
      let precursorMatch = 'General Oilfield Operation';

      if (text.includes('loto') || text.includes('isolation') || text.includes('valve') || text.includes('gas') || text.includes('detector') || text.includes('hot work')) {
        if (cand.activity.toLowerCase().includes('hot work') || cand.equipment.toLowerCase().includes('piping') || cand.equipment.toLowerCase().includes('wellhead')) {
          score = 92;
          precursorMatch = 'Identical Energy Isolation & Flammable Gas Boundary';
        } else if (cand.activity.toLowerCase().includes('drilling') || cand.equipment.toLowerCase().includes('mud pump')) {
          score = 86;
          precursorMatch = 'High-Pressure Barrier & Permit Verification Match';
        } else {
          score = 81;
          precursorMatch = 'Shared Hazardous Classified Zone Work Envelope';
        }
      } else if (text.includes('height') || text.includes('harness') || text.includes('scaffold') || text.includes('board')) {
        if (cand.activity.toLowerCase().includes('tripping') || cand.equipment.toLowerCase().includes('drawworks')) {
          score = 94;
          precursorMatch = 'Derrick / Mast Elevated Work Operation';
        } else {
          score = 84;
          precursorMatch = 'Working at Height Activity Overlap';
        }
      } else if (text.includes('pressure') || text.includes('psi') || text.includes('mud pump') || text.includes('whip')) {
        if (cand.equipment.toLowerCase().includes('mud pump') || cand.equipment.toLowerCase().includes('bop')) {
          score = 91;
          precursorMatch = 'High Pressure Fluid / Hydraulic Line Hazard';
        } else {
          score = 82;
          precursorMatch = 'Pressurized Surface Equipment Precursor';
        }
      }

      return {
        site: cand.site,
        rigId: cand.rigId,
        activity: cand.activity,
        equipment: cand.equipment,
        similarityScore: score,
        status: cand.status,
        riskScore: cand.riskScore,
        lastReportDate: cand.lastReportDate,
        precursorMatch,
      };
    }).sort((a, b) => b.similarityScore - a.similarityScore);
  }
}

export const reportsRepo = new ReportsRepository();
